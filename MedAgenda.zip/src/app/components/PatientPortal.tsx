import { format, parseISO, isValid } from "date-fns";
import { ptBR } from "date-fns/locale";
import { AppointmentForm } from "./AppointmentForm";
import { Patient } from "./PatientRegistration";
import { Doctor } from "./DoctorRegistration";
import { HealthInsurance } from "./HealthInsuranceRegistration";
import { Badge } from "./ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./ui/card";
import { Button } from "./ui/button";
import {
  CalendarCheck,
  LogOut,
  Calendar,
  Clock,
  Stethoscope,
  CreditCard,
  Building2,
  DollarSign,
  UserCircle2,
  ClipboardList,
  FileText,
} from "lucide-react";

export interface Appointment {
  id: string;
  date: Date;
  time: string;
  name: string;
  cpf: string;
  phone: string;
  doctor: string;
  service: string;
  paymentType: "particular" | "insurance";
  insuranceProvider?: string;
  consultationPrice?: string;
  observations?: string;
  completed?: boolean;
}

interface PatientPortalProps {
  patient: Patient;
  appointments: Appointment[];
  bookedSlots: { date: Date; time: string; doctor: string }[];
  onNewAppointment: (data: Omit<Appointment, "id">) => void;
  onLogout: () => void;
  doctors: Doctor[];
  healthInsurances: HealthInsurance[];
}

export function PatientPortal({
  patient,
  appointments,
  bookedSlots,
  onNewAppointment,
  onLogout,
  doctors,
  healthInsurances,
}: PatientPortalProps) {
  // Função auxiliar para garantir que temos um Date object válido
  const normalizeDate = (date: Date | string): Date => {
    if (date instanceof Date) {
      return date;
    }
    // Se for string, faz parse considerando timezone local
    if (typeof date === 'string') {
      // Se estiver no formato ISO (yyyy-mm-dd), adiciona horário local
      if (/^\d{4}-\d{2}-\d{2}$/.test(date)) {
        const [year, month, day] = date.split('-').map(Number);
        return new Date(year, month - 1, day);
      }
      // Caso contrário, tenta parseISO
      const parsed = parseISO(date);
      return isValid(parsed) ? parsed : new Date(date);
    }
    return new Date(date);
  };

  // Filtra apenas os agendamentos deste paciente
  const myAppointments = [...appointments]
    .filter((apt) => apt.cpf === patient.cpf)
    .sort((a, b) => {
      const dateA = normalizeDate(a.date);
      const dateB = normalizeDate(b.date);
      return dateA.getTime() !== dateB.getTime()
        ? dateA.getTime() - dateB.getTime()
        : a.time.localeCompare(b.time);
    });

  const isPast = (date: Date | string, time: string) => {
    const [h, m] = time.split(":").map(Number);
    const d = normalizeDate(date);
    d.setHours(h, m, 0, 0);
    return d < new Date();
  };

  const upcoming = myAppointments.filter((a) => !isPast(a.date, a.time));
  const past = myAppointments.filter((a) => isPast(a.date, a.time));

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-cyan-100">
      {/* Header */}
      <header className="bg-white border-b shadow-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-teal-600 p-2 rounded-xl">
              <CalendarCheck className="h-6 w-6 text-white" />
            </div>
            <div>
              <p className="text-teal-700" style={{ fontSize: "1.1rem", fontWeight: 700 }}>
                MedAgenda
              </p>
              <p className="text-muted-foreground" style={{ fontSize: "0.75rem" }}>
                Área do Paciente
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-teal-50 border border-teal-100 rounded-lg">
              <UserCircle2 className="h-4 w-4 text-teal-600" />
              <span className="text-teal-700" style={{ fontSize: "0.85rem", fontWeight: 500 }}>
                {patient.name.split(" ")[0]}
              </span>
            </div>
            <Button
              variant="outline"
              onClick={onLogout}
              className="flex items-center gap-2 border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300"
            >
              <LogOut className="h-4 w-4" />
              <span className="hidden sm:inline">Sair</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Boas-vindas */}
        <div className="mb-8">
          <h1 className="text-3xl" style={{ fontWeight: 700 }}>
            Olá, {patient.name.split(" ")[0]}! 👋
          </h1>
          <p className="text-muted-foreground mt-1">
            Gerencie seus agendamentos ou marque uma nova consulta.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Formulário de agendamento */}
          <div>
            <AppointmentForm
              onSubmit={onNewAppointment}
              bookedSlots={bookedSlots}
              patients={[patient]}
              lockedPatient={patient}
              doctors={doctors}
              healthInsurances={healthInsurances}
            />
          </div>

          {/* Meus agendamentos */}
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <ClipboardList className="h-5 w-5 text-teal-600" />
                  <CardTitle>Meus Agendamentos</CardTitle>
                </div>
                <CardDescription>
                  {myAppointments.length === 0
                    ? "Nenhum agendamento registrado"
                    : `${upcoming.length} próximo(s) · ${past.length} realizado(s)`}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {myAppointments.length === 0 ? (
                  <div className="text-center py-10 text-muted-foreground">
                    <CalendarCheck className="h-10 w-10 mx-auto mb-3 opacity-30" />
                    <p>Você ainda não tem consultas agendadas.</p>
                    <p style={{ fontSize: "0.875rem" }}>
                      Use o formulário ao lado para marcar sua consulta.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {/* Próximos */}
                    {upcoming.length > 0 && (
                      <div>
                        <p
                          className="text-teal-700 mb-2"
                          style={{ fontSize: "0.8rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.05em" }}
                        >
                          Próximas consultas
                        </p>
                        <div className="space-y-3">
                          {upcoming.map((apt) => (
                            <AppointmentCard
                              key={apt.id}
                              appointment={apt}
                              past={false}
                              onEdit={() => {}}
                              onCancel={() => {}}
                            />
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Realizadas */}
                    {past.length > 0 && (
                      <div className="mt-4">
                        <p
                          className="text-muted-foreground mb-2"
                          style={{ fontSize: "0.8rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.05em" }}
                        >
                          Realizadas
                        </p>
                        <div className="space-y-3 opacity-60">
                          {past.map((apt) => (
                            <AppointmentCard
                              key={apt.id}
                              appointment={apt}
                              past={true}
                              onEdit={() => {}}
                              onCancel={() => {}}
                            />
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

// Sub-componente de card de agendamento
function AppointmentCard({
  appointment,
  past,
  onEdit,
  onCancel,
}: {
  appointment: Appointment;
  past: boolean;
  onEdit: () => void;
  onCancel: () => void;
}) {
  return (
    <div
      className={`rounded-lg border p-4 space-y-3 ${
        past ? "bg-muted/20" : "bg-white shadow-sm"
      }`}
    >
      {/* Médico */}
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2">
          <Stethoscope className="h-4 w-4 text-teal-600" />
          <span style={{ fontWeight: 500 }}>{appointment.doctor}</span>
        </div>
      </div>

      {/* Infos */}
      <div className="flex flex-wrap gap-2">
        <Badge variant="secondary" className="gap-1 text-xs">
          <Calendar className="h-3 w-3" />
          {format(new Date(appointment.date), "dd/MM/yyyy", { locale: ptBR })}
        </Badge>
        <Badge variant="secondary" className="gap-1 text-xs">
          <Clock className="h-3 w-3" />
          {appointment.time}
        </Badge>
        <Badge variant="outline" className="text-xs">
          {appointment.service}
        </Badge>
        <Badge
          variant={appointment.paymentType === "particular" ? "default" : "secondary"}
          className="gap-1 text-xs"
        >
          <CreditCard className="h-3 w-3" />
          {appointment.paymentType === "particular" ? "Particular" : "Convênio"}
        </Badge>
        {past && <Badge variant="destructive" className="text-xs">Realizado</Badge>}
      </div>

      {/* Convênio ou valor */}
      {appointment.insuranceProvider && (
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <Building2 className="h-3 w-3" />
          {appointment.insuranceProvider}
        </div>
      )}
      {appointment.consultationPrice && (
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <DollarSign className="h-3 w-3" />
          R$ {appointment.consultationPrice}
        </div>
      )}
      {appointment.observations && (
        <div className="flex items-start gap-1 text-sm text-muted-foreground">
          <FileText className="h-3 w-3 mt-0.5" />
          {appointment.observations}
        </div>
      )}
    </div>
  );
}