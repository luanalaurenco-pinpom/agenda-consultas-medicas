import { useState } from "react";
import { AppointmentForm } from "./components/AppointmentForm";
import { AppointmentList } from "./components/AppointmentList";
import {
  PatientRegistration,
  Patient,
} from "./components/PatientRegistration";
import {
  DoctorRegistration,
  Doctor,
} from "./components/DoctorRegistration";
import {
  HealthInsuranceRegistration,
  HealthInsurance,
} from "./components/HealthInsuranceRegistration";
import { PatientPortal } from "./components/PatientPortal";
import { DoctorPortal } from "./components/DoctorPortal";
import { LoginScreen } from "./components/LoginScreen";
import { PublicPatientRegistration } from "./components/PublicPatientRegistration";
import { Toaster } from "./components/ui/sonner";
import { toast } from "sonner";
import {
  CalendarCheck,
  Users,
  Calendar,
  LogOut,
  ShieldCheck,
  Stethoscope,
  Shield,
} from "lucide-react";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "./components/ui/tabs";
import { Button } from "./components/ui/button";
import { Appointment } from "./components/EditAppointmentModal";

type AuthState =
  | { role: "admin" }
  | { role: "patient"; patient: Patient }
  | { role: "doctor"; doctor: Doctor }
  | null;

type ViewState = "login" | "register" | "app";

export default function App() {
  const [auth, setAuth] = useState<AuthState>(null);
  const [view, setView] = useState<ViewState>("login");
  const [appointments, setAppointments] = useState<
    Appointment[]
  >([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [healthInsurances, setHealthInsurances] = useState<
    HealthInsurance[]
  >([]);

  // ─── Handlers de auth ───────────────────────────────────────────────────────
  const handleAdminLogin = () => {
    setAuth({ role: "admin" });
    toast.success("Login realizado com sucesso!", {
      description: "Bem-vindo ao painel de operação.",
    });
  };

  const handlePatientLogin = (patient: Patient) => {
    setAuth({ role: "patient", patient });
    toast.success(
      `Bem-vindo(a), ${patient.name.split(" ")[0]}!`,
      {
        description:
          "Você pode agendar e gerenciar suas consultas.",
      },
    );
  };

  const handleDoctorLogin = (doctor: Doctor) => {
    setAuth({ role: "doctor", doctor });
    toast.success(`Bem-vindo(a), Dr(a). ${doctor.name}!`, {
      description: "Visualize suas consultas agendadas.",
    });
  };

  const handleLogout = () => {
    setAuth(null);
    setView("login");
    toast.info("Sessão encerrada.");
  };

  // ─── Handlers de agendamentos ────────────────────────────────────────────────
  const handleNewAppointment = (
    appointmentData: Omit<Appointment, "id">,
  ) => {
    const newAppointment: Appointment = {
      ...appointmentData,
      id: Date.now().toString(),
    };
    setAppointments((prev) => [...prev, newAppointment]);
    toast.success("Agendamento confirmado!", {
      description: `${appointmentData.name} — ${appointmentData.doctor} — ${appointmentData.time}`,
    });
  };

  const handleCancelAppointment = (id: string) => {
    setAppointments((prev) =>
      prev.filter((apt) => apt.id !== id),
    );
    toast.error("Agendamento cancelado");
  };

  const handleEditAppointment = (updated: Appointment) => {
    setAppointments((prev) =>
      prev.map((apt) =>
        apt.id === updated.id ? updated : apt,
      ),
    );
    toast.success("Agendamento atualizado!", {
      description: `${updated.name} — ${updated.doctor} — ${updated.time}`,
    });
  };

  const handleToggleComplete = (id: string) => {
    setAppointments((prev) =>
      prev.map((apt) =>
        apt.id === id
          ? { ...apt, completed: !apt.completed }
          : apt,
      ),
    );
    const appointment = appointments.find(
      (apt) => apt.id === id,
    );
    if (appointment) {
      toast.success(
        appointment.completed
          ? "Consulta marcada como não realizada"
          : "Consulta marcada como realizada",
      );
    }
  };

  // ─── Handlers de pacientes ───────────────────────────────────────────────────
  const handlePatientRegister = (
    patient: Omit<Patient, "id">,
  ) => {
    const newPatient: Patient = {
      ...patient,
      id: `patient-${Date.now()}`,
      hasHealthInsurance: patient.hasHealthInsurance || false,
      healthInsuranceName: patient.healthInsuranceName || "",
    };
    setPatients([...patients, newPatient]);
    toast.success("Paciente cadastrado com sucesso!", {
      description: `${patient.name} foi adicionado ao sistema.`,
    });
  };

  const handleDeletePatient = (id: string) => {
    setPatients((prev) => prev.filter((p) => p.id !== id));
    toast.error("Paciente removido do sistema");
  };

  const handleEditPatient = (
    id: string,
    patientData: Omit<Patient, "id">,
  ) => {
    setPatients((prev) =>
      prev.map((p) =>
        p.id === id ? { ...patientData, id } : p,
      ),
    );
    toast.success("Paciente atualizado com sucesso!", {
      description: patientData.name,
    });
  };

  // ─── Handlers de médicos ─────────────────────────────────────────────────────
  const handleRegisterDoctor = (
    doctorData: Omit<Doctor, "id">,
  ) => {
    const newDoctor: Doctor = {
      ...doctorData,
      id: Date.now().toString(),
    };
    setDoctors((prev) => [...prev, newDoctor]);
    toast.success("Médico cadastrado com sucesso!", {
      description: doctorData.name,
    });
  };

  const handleDeleteDoctor = (id: string) => {
    setDoctors((prev) => prev.filter((d) => d.id !== id));
    toast.error("Médico removido do sistema");
  };

  const handleEditDoctor = (
    id: string,
    doctorData: Omit<Doctor, "id">,
  ) => {
    setDoctors((prev) =>
      prev.map((d) =>
        d.id === id ? { ...doctorData, id } : d,
      ),
    );
    toast.success("Médico atualizado com sucesso!", {
      description: doctorData.name,
    });
  };

  // ─── Handlers de convênios de saúde ──────────────────────────────────────────
  const handleRegisterHealthInsurance = (
    healthInsuranceData: Omit<HealthInsurance, "id">,
  ) => {
    const newHealthInsurance: HealthInsurance = {
      ...healthInsuranceData,
      id: Date.now().toString(),
    };
    setHealthInsurances((prev) => [
      ...prev,
      newHealthInsurance,
    ]);
    toast.success("Convênio de saúde cadastrado com sucesso!", {
      description: healthInsuranceData.name,
    });
  };

  const handleDeleteHealthInsurance = (id: string) => {
    setHealthInsurances((prev) =>
      prev.filter((hi) => hi.id !== id),
    );
    toast.error("Convênio de saúde removido do sistema");
  };

  const bookedSlots = appointments.map((apt) => ({
    date: apt.date,
    time: apt.time,
    doctor: apt.doctor,
  }));

  // ─── Tela de login ───────────────────────────────────────────────────────────
  if (!auth) {
    if (view === "register") {
      return (
        <>
          <PublicPatientRegistration
            patients={patients}
            onRegister={handlePatientRegister}
            onBack={() => setView("login")}
            healthInsurances={healthInsurances}
          />
          <Toaster />
        </>
      );
    }

    return (
      <>
        <LoginScreen
          onAdminLogin={handleAdminLogin}
          onPatientLogin={handlePatientLogin}
          onDoctorLogin={handleDoctorLogin}
          onRegisterClick={() => setView("register")}
          patients={patients}
          doctors={doctors}
        />
        <Toaster />
      </>
    );
  }

  // ─── Portal do paciente ──────────────────────────────────────────────────────
  if (auth.role === "patient") {
    return (
      <>
        <PatientPortal
          patient={auth.patient}
          appointments={appointments}
          bookedSlots={bookedSlots}
          onNewAppointment={handleNewAppointment}
          onLogout={handleLogout}
          doctors={doctors}
          healthInsurances={healthInsurances}
        />
        <Toaster />
      </>
    );
  }

  // ─── Portal do médico ────────────────────────────────────────────────────────
  if (auth.role === "doctor") {
    return (
      <>
        <DoctorPortal
          doctor={auth.doctor}
          appointments={appointments}
          onLogout={handleLogout}
          onToggleComplete={handleToggleComplete}
        />
        <Toaster />
      </>
    );
  }

  // ─── Painel administrativo ───────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <CalendarCheck className="h-10 w-10 text-primary" />
              <div>
                <h1 className="text-4xl font-bold">
                  Sistema de Agendamento Médico
                </h1>
                <p className="text-muted-foreground">
                  Gerencie pacientes e agendamentos de forma
                  simples e eficiente
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-blue-50 border border-blue-100 rounded-lg">
                <ShieldCheck className="h-4 w-4 text-blue-600" />
                <span
                  className="text-blue-700"
                  style={{
                    fontSize: "0.85rem",
                    fontWeight: 500,
                  }}
                >
                  Operador
                </span>
              </div>
              <Button
                variant="outline"
                onClick={handleLogout}
                className="flex items-center gap-2 border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300"
              >
                <LogOut className="h-4 w-4" />
                <span className="hidden sm:inline">Sair</span>
              </Button>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto">
          <Tabs defaultValue="appointments" className="w-full">
            <TabsList className="grid w-full max-w-4xl mx-auto grid-cols-4 mb-6">
              <TabsTrigger
                value="appointments"
                className="flex items-center gap-2"
              >
                <Calendar className="h-4 w-4" />
                Agendamentos
              </TabsTrigger>
              <TabsTrigger
                value="patients"
                className="flex items-center gap-2"
              >
                <Users className="h-4 w-4" />
                Pacientes
              </TabsTrigger>
              <TabsTrigger
                value="doctors"
                className="flex items-center gap-2"
              >
                <Stethoscope className="h-4 w-4" />
                Médicos
              </TabsTrigger>
              <TabsTrigger
                value="insurances"
                className="flex items-center gap-2"
              >
                <Shield className="h-4 w-4" />
                Planos de Saúde
              </TabsTrigger>
            </TabsList>

            <TabsContent value="appointments">
              <div className="max-w-2xl mx-auto space-y-6">
                <AppointmentForm
                  onSubmit={handleNewAppointment}
                  bookedSlots={bookedSlots}
                  patients={patients}
                  doctors={doctors}
                  healthInsurances={healthInsurances}
                />
                <AppointmentList
                  appointments={appointments}
                  onCancel={handleCancelAppointment}
                  onEdit={handleEditAppointment}
                  onToggleComplete={handleToggleComplete}
                  bookedSlots={bookedSlots}
                  doctors={doctors}
                />
              </div>
            </TabsContent>

            <TabsContent value="patients">
              <div className="max-w-2xl mx-auto">
                <PatientRegistration
                  patients={patients}
                  onRegister={handlePatientRegister}
                  onEdit={handleEditPatient}
                  onDelete={handleDeletePatient}
                  healthInsurances={healthInsurances}
                />
              </div>
            </TabsContent>

            <TabsContent value="doctors">
              <div className="max-w-2xl mx-auto">
                <DoctorRegistration
                  doctors={doctors}
                  onRegister={handleRegisterDoctor}
                  onDelete={handleDeleteDoctor}
                  onEdit={handleEditDoctor}
                />
              </div>
            </TabsContent>

            <TabsContent value="insurances">
              <div className="max-w-2xl mx-auto">
                <HealthInsuranceRegistration
                  insurances={healthInsurances}
                  onRegister={handleRegisterHealthInsurance}
                  onDelete={handleDeleteHealthInsurance}
                />
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      <Toaster />
    </div>
  );
}