import { useState, useEffect } from "react";
import { Calendar } from "./ui/calendar";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Alert, AlertDescription } from "./ui/alert";
import { Badge } from "./ui/badge";
import { Checkbox } from "./ui/checkbox";
import { Calendar as CalendarIcon, CreditCard, AlertCircle, CheckCircle2, Shield, AlertTriangle, Mail, MessageSquare } from "lucide-react";
import { format, getDay } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Patient } from "./PatientRegistration";
import { Doctor } from "./DoctorRegistration";
import { HealthInsurance } from "./HealthInsuranceRegistration";

const TIME_SLOTS = [
  "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", 
  "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30",
  "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30",
  "19:00", "19:30", "20:00"
];

const SERVICES = [
  "Consulta Geral",
  "Avaliação",
  "Retorno",
  "Exame Laboratorial",
  "Exame de Imagem",
  "Procedimento Cirúrgico",
  "Fisioterapia",
  "Psicologia",
  "Odontologia"
];

// Mapeamento de serviços para tipos de cobertura necessários
const SERVICE_COVERAGE_MAP: { [key: string]: string[] } = {
  "Consulta Geral": ["ambulatorial"],
  "Avaliação": ["ambulatorial"],
  "Retorno": ["ambulatorial"],
  "Exame Laboratorial": ["laboratorio"],
  "Exame de Imagem": ["imagem"],
  "Procedimento Cirúrgico": ["hospitalar"],
  "Fisioterapia": ["terapias"],
  "Psicologia": ["terapias"],
  "Odontologia": ["odontologico"],
};

interface AppointmentFormProps {
  onSubmit: (appointment: {
    cpf: string;
    name: string;
    email: string;
    phone: string;
    date: Date;
    time: string;
    service: string;
    paymentType: string;
    specialty: string;
    doctor: string;
    insuranceProvider?: string;
    healthInsuranceCardNumber?: string;
    consultationPrice?: string;
    observations?: string;
  }) => void;
  bookedSlots: { date: Date; time: string; doctor: string }[];
  patients: Patient[];
  doctors: Doctor[];
  healthInsurances: HealthInsurance[];
  lockedPatient?: Patient;
}

export function AppointmentForm({ onSubmit, bookedSlots, patients, doctors, healthInsurances, lockedPatient }: AppointmentFormProps) {
  const [date, setDate] = useState<Date>();
  const [time, setTime] = useState<string>("");
  const [cpf, setCpf] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [service, setService] = useState("");
  const [paymentType, setPaymentType] = useState<string>("");
  const [specialty, setSpecialty] = useState("");
  const [doctor, setDoctor] = useState("");
  const [insuranceProvider, setInsuranceProvider] = useState("");
  const [healthInsuranceCardNumber, setHealthInsuranceCardNumber] = useState("");
  const [consultationPrice, setConsultationPrice] = useState("");
  const [isPatientFound, setIsPatientFound] = useState(false);
  const [observations, setObservations] = useState("");
  const [reminderWhatsApp, setReminderWhatsApp] = useState(false);
  const [reminderEmail, setReminderEmail] = useState(false);
  const [foundPatient, setFoundPatient] = useState<Patient | null>(null);

  // Mapeia número do dia da semana para nome
  const getDayName = (dayNumber: number): string => {
    const days = ["Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado"];
    return days[dayNumber];
  };

  // Verifica se o médico atende no dia da semana selecionado
  const isDoctorAvailableOnDay = (doctorName: string, selectedDate: Date): boolean => {
    const selectedDoctor = doctors.find(d => d.name === doctorName);
    if (!selectedDoctor || !selectedDoctor.availability || selectedDoctor.availability.length === 0) {
      return true; // Se não há disponibilidade configurada, permite agendar
    }
    
    const dayOfWeek = getDayName(getDay(selectedDate));
    return selectedDoctor.availability.some(avail => avail.dayOfWeek === dayOfWeek);
  };

  // Filtra horários disponíveis baseado na disponibilidade do médico
  const getAvailableTimeSlots = (): string[] => {
    if (!date || !doctor) return TIME_SLOTS;
    
    const selectedDoctor = doctors.find(d => d.name === doctor);
    if (!selectedDoctor || !selectedDoctor.availability || selectedDoctor.availability.length === 0) {
      return TIME_SLOTS; // Se não há disponibilidade configurada, mostra todos os horários
    }
    
    const dayOfWeek = getDayName(getDay(date));
    const availability = selectedDoctor.availability.find(avail => avail.dayOfWeek === dayOfWeek);
    
    if (!availability) return []; // Se médico não atende neste dia, não mostra horários
    
    // Filtra horários que estão dentro do período de atendimento
    const timeToMinutes = (time: string) => {
      const [hours, minutes] = time.split(':').map(Number);
      return hours * 60 + minutes;
    };
    
    const startMinutes = timeToMinutes(availability.startTime);
    const endMinutes = timeToMinutes(availability.endTime);
    
    return TIME_SLOTS.filter(slot => {
      const slotMinutes = timeToMinutes(slot);
      return slotMinutes >= startMinutes && slotMinutes <= endMinutes;
    });
  };

  const availableSlots = getAvailableTimeSlots();

  // Pré-preenche quando há paciente bloqueado
  useEffect(() => {
    if (lockedPatient) {
      setCpf(lockedPatient.cpf);
      setName(lockedPatient.name);
      setEmail(lockedPatient.email);
      setPhone(lockedPatient.phone);
      setIsPatientFound(true);
      setFoundPatient(lockedPatient);
    }
  }, [lockedPatient]);

  const formatCPF = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    if (numbers.length <= 11) {
      return numbers
        .replace(/(\d{3})(\d)/, "$1.$2")
        .replace(/(\d{3})(\d)/, "$1.$2")
        .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
    }
    return cpf;
  };

  const handleCpfChange = (value: string) => {
    if (lockedPatient) return; // não permite edição se paciente bloqueado
    const formattedCpf = formatCPF(value);
    setCpf(formattedCpf);

    // Buscar paciente quando o CPF tiver 14 caracteres (formatado)
    if (formattedCpf.length === 14) {
      const patient = patients.find(p => p.cpf === formattedCpf);
      if (patient) {
        setName(patient.name);
        setEmail(patient.email);
        setPhone(patient.phone);
        setIsPatientFound(true);
        setFoundPatient(patient);
        // Pré-selecionar convênio se paciente tiver plano de saúde
        if (patient.hasHealthInsurance && patient.healthInsuranceName) {
          setInsuranceProvider(patient.healthInsuranceName);
        }
      } else {
        setName("");
        setEmail("");
        setPhone("");
        setIsPatientFound(false);
        setFoundPatient(null);
        setInsuranceProvider("");
      }
    } else {
      setIsPatientFound(false);
      setFoundPatient(null);
      setInsuranceProvider("");
    }
  };

  const isSlotBooked = (slot: string) => {
    if (!date) return false;
    return bookedSlots.some(
      (booked) =>
        format(booked.date, "yyyy-MM-dd") === format(date, "yyyy-MM-dd") &&
        booked.time === slot &&
        booked.doctor === doctor
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const baseValidation = date && time && cpf && name && email && phone && service && paymentType && specialty && doctor;
    const paymentValidation = 
      (paymentType === "convenio" && insuranceProvider) ||
      (paymentType === "particular" && consultationPrice);
    
    if (baseValidation && paymentValidation) {
      onSubmit({ 
        cpf,
        name, 
        email, 
        phone, 
        date, 
        time, 
        service, 
        paymentType,
        specialty,
        doctor,
        ...(paymentType === "convenio" && { insuranceProvider }),
        ...(paymentType === "convenio" && { healthInsuranceCardNumber }),
        ...(paymentType === "particular" && { consultationPrice }),
        observations,
      });
      // Reset form (mantém dados se paciente bloqueado)
      setDate(undefined);
      setTime("");
      if (!lockedPatient) {
        setCpf("");
        setName("");
        setEmail("");
        setPhone("");
        setIsPatientFound(false);
        setFoundPatient(null);
      }
      setService("");
      setPaymentType("");
      setSpecialty("");
      setDoctor("");
      setInsuranceProvider("");
      setHealthInsuranceCardNumber("");
      setConsultationPrice("");
      setObservations("");
    }
  };

  const isFormValid = 
    date && 
    time && 
    cpf &&
    name && 
    email && 
    phone && 
    service && 
    paymentType &&
    specialty &&
    doctor &&
    ((paymentType === "convenio" && insuranceProvider) ||
     (paymentType === "particular" && consultationPrice));

  // Obter lista única de especialidades
  const specialties = Array.from(new Set(doctors.map(d => d.specialty))).sort();

  // Filtrar médicos por especialidade
  const filteredDoctors = specialty 
    ? doctors.filter(d => d.specialty === specialty && d.isActive !== false)
    : [];

  // Resetar médico quando especialidade mudar
  const handleSpecialtyChange = (value: string) => {
    setSpecialty(value);
    setDoctor(""); // Limpa o médico selecionado
  };

  // Verificar cobertura do plano
  const checkCoverage = () => {
    if (paymentType !== "convenio" || !insuranceProvider || !service) {
      return { covered: true, message: "" };
    }

    const selectedPlan = healthInsurances.find(ins => ins.name === insuranceProvider);
    if (!selectedPlan) {
      return { covered: false, message: "Plano não encontrado" };
    }

    const requiredCoverages = SERVICE_COVERAGE_MAP[service] || [];
    const hasCoverage = requiredCoverages.some(coverage => 
      selectedPlan.coverageTypes.includes(coverage)
    );

    if (!hasCoverage) {
      return {
        covered: false,
        message: `O plano ${insuranceProvider} não oferece cobertura para ${service}. Escolha outro plano ou pague particular.`
      };
    }

    return { covered: true, message: `✓ Cobertura confirmada para ${service}` };
  };

  const coverageCheck = checkCoverage();
  const hasCoverageIssue = paymentType === "convenio" && insuranceProvider && service && !coverageCheck.covered;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Novo Agendamento</CardTitle>
        <CardDescription>
          Preencha as informações para agendar um horário
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="cpf">CPF</Label>
            <div className="relative">
              <CreditCard className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                id="cpf"
                type="text"
                placeholder="000.000.000-00"
                value={cpf}
                onChange={(e) => handleCpfChange(e.target.value)}
                className="pl-10"
                required
                disabled={!!lockedPatient}
              />
            </div>
            {isPatientFound && (
              <p className="text-sm text-green-600">✓ Paciente encontrado no sistema</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="name">Nome Completo</Label>
            <Input
              id="name"
              placeholder="Digite seu nome"
              value={name}
              onChange={(e) => setName(e.target.value)}
              disabled={isPatientFound}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">E-mail</Label>
            <Input
              id="email"
              type="email"
              placeholder="seu@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={isPatientFound}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Telefone</Label>
            <Input
              id="phone"
              type="tel"
              placeholder="(00) 00000-0000"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              disabled={isPatientFound}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Tipo de Atendimento</Label>
            {isPatientFound && foundPatient ? (
              // Paciente encontrado - mostrar apenas opções disponíveis
              <RadioGroup value={paymentType} onValueChange={setPaymentType}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="particular" id="particular" />
                  <Label htmlFor="particular" className="cursor-pointer">Particular</Label>
                </div>
                {foundPatient.hasHealthInsurance && foundPatient.healthInsuranceName && (
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="convenio" id="convenio" />
                    <Label htmlFor="convenio" className="cursor-pointer">
                      Convênio - {foundPatient.healthInsuranceName}
                    </Label>
                  </div>
                )}
                {foundPatient.hasHealthInsurance && !foundPatient.healthInsuranceName && (
                  <p className="text-sm text-amber-600 p-2 bg-amber-50 rounded-md border border-amber-200">
                    ⚠️ Paciente possui plano de saúde, mas o convênio não foi especificado no cadastro.
                  </p>
                )}
                {!foundPatient.hasHealthInsurance && (
                  <p className="text-sm text-blue-600 p-2 bg-blue-50 rounded-md border border-blue-200">
                    ℹ️ Este paciente não possui plano de saúde cadastrado. Apenas atendimento particular disponível.
                  </p>
                )}
              </RadioGroup>
            ) : (
              // Paciente não encontrado - permitir escolher
              <RadioGroup value={paymentType} onValueChange={setPaymentType}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="particular" id="particular" />
                  <Label htmlFor="particular" className="cursor-pointer">Particular</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="convenio" id="convenio" />
                  <Label htmlFor="convenio" className="cursor-pointer">Convênio</Label>
                </div>
              </RadioGroup>
            )}
          </div>

          <div className="space-y-2">
            <Label>Especialidade</Label>
            <Select value={specialty} onValueChange={handleSpecialtyChange}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione a especialidade" />
              </SelectTrigger>
              <SelectContent>
                {specialties.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Médico(a)</Label>
            <Select value={doctor} onValueChange={setDoctor}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o médico(a)" />
              </SelectTrigger>
              <SelectContent>
                {filteredDoctors.map((doc) => (
                  <SelectItem key={doc.name} value={doc.name}>
                    {doc.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Serviço</Label>
            <Select value={service} onValueChange={setService}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o serviço" />
              </SelectTrigger>
              <SelectContent>
                {SERVICES.map((svc) => (
                  <SelectItem key={svc} value={svc}>
                    {svc}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Data</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, "PPP", { locale: ptBR }) : "Selecione a data"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          {date && (
            <div className="space-y-2">
              {doctor && !isDoctorAvailableOnDay(doctor, date) && (
                <Alert variant="destructive" className="mb-2">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>{doctor}</strong> não atende às {getDayName(getDay(date))}s. Por favor, selecione outra data ou médico.
                  </AlertDescription>
                </Alert>
              )}
              
              {doctor && isDoctorAvailableOnDay(doctor, date) && availableSlots.length === 0 && (
                <Alert variant="destructive" className="mb-2">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    Este médico não possui horários de atendimento configurados para {getDayName(getDay(date))}.
                  </AlertDescription>
                </Alert>
              )}
              
              <Label>Horário</Label>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                {availableSlots.length > 0 ? (
                  availableSlots.map((slot) => {
                    const booked = isSlotBooked(slot);
                    return (
                      <Button
                        key={slot}
                        type="button"
                        variant={time === slot ? "default" : "outline"}
                        className="w-full"
                        onClick={() => setTime(slot)}
                        disabled={booked}
                      >
                        {slot}
                      </Button>
                    );
                  })
                ) : (
                  doctor && (
                    <div className="col-span-3 sm:col-span-4 text-center p-4 text-muted-foreground text-sm border-2 border-dashed rounded-md">
                      Nenhum horário disponível para este dia
                    </div>
                  )
                )}
              </div>
            </div>
          )}

          {paymentType === "convenio" && (
            <div className="space-y-2">
              <Label>Convênio</Label>
              <Select value={insuranceProvider} onValueChange={setInsuranceProvider}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o convênio" />
                </SelectTrigger>
                <SelectContent>
                  {healthInsurances.length === 0 ? (
                    <div className="px-2 py-1.5 text-sm text-muted-foreground">
                      Nenhum plano cadastrado
                    </div>
                  ) : (
                    healthInsurances.map((provider) => (
                      <SelectItem key={provider.name} value={provider.name}>
                        {provider.name}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
              
              {/* Mostrar coberturas do plano selecionado */}
              {insuranceProvider && (() => {
                const selectedPlan = healthInsurances.find(ins => ins.name === insuranceProvider);
                if (selectedPlan) {
                  return (
                    <div className="p-3 bg-blue-50 border border-blue-200 rounded-md">
                      <div className="flex items-start gap-2">
                        <Shield className="h-4 w-4 text-blue-600 mt-0.5" />
                        <div className="flex-1">
                          <p className="text-xs font-medium text-blue-900 mb-2">Coberturas deste plano:</p>
                          <div className="flex flex-wrap gap-1">
                            {selectedPlan.coverageTypes.map((coverageId) => {
                              const coverageLabels: { [key: string]: string } = {
                                ambulatorial: "Ambulatorial",
                                hospitalar: "Hospitalar",
                                obstetricia: "Obstétrico",
                                odontologico: "Odontológico",
                                urgencia: "Urgência/Emergência",
                                laboratorio: "Exames Lab.",
                                imagem: "Exames de Imagem",
                                terapias: "Terapias",
                                home_care: "Home Care",
                                referencia: "Cobertura Nacional",
                              };
                              return (
                                <Badge key={coverageId} variant="secondary" className="text-xs">
                                  {coverageLabels[coverageId] || coverageId}
                                </Badge>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                }
                return null;
              })()}
              
              <div className="space-y-2">
                <Label htmlFor="healthInsuranceCardNumber">Número da Carteirinha</Label>
                <div className="relative">
                  <CreditCard className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="healthInsuranceCardNumber"
                    type="text"
                    placeholder="Digite o número da carteirinha"
                    value={healthInsuranceCardNumber}
                    onChange={(e) => setHealthInsuranceCardNumber(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
            </div>
          )}

          {paymentType === "particular" && (
            <div className="space-y-2">
              <Label>Valor da Consulta</Label>
              <Input
                id="consultationPrice"
                type="number"
                placeholder="Digite o valor"
                value={consultationPrice}
                onChange={(e) => setConsultationPrice(e.target.value)}
                required
              />
            </div>
          )}

          <div className="space-y-2">
            <Label>Observações</Label>
            <Input
              id="observations"
              placeholder="Digite observações"
              value={observations}
              onChange={(e) => setObservations(e.target.value)}
            />
          </div>

          {/* Lembretes de consulta */}
          <div className="space-y-3">
            <Label>Deseja receber lembrete da consulta um dia antes?</Label>
            <div className="p-4 border rounded-lg bg-muted/30 space-y-3">
              <div className="flex items-center space-x-3">
                <Checkbox
                  id="reminder-whatsapp"
                  checked={reminderWhatsApp}
                  onCheckedChange={(checked) => setReminderWhatsApp(checked as boolean)}
                />
                <Label htmlFor="reminder-whatsapp" className="flex items-center gap-2 cursor-pointer font-normal">
                  <MessageSquare className="h-4 w-4 text-green-600" />
                  <span>Enviar lembrete por WhatsApp</span>
                </Label>
              </div>
              <div className="flex items-center space-x-3">
                <Checkbox
                  id="reminder-email"
                  checked={reminderEmail}
                  onCheckedChange={(checked) => setReminderEmail(checked as boolean)}
                />
                <Label htmlFor="reminder-email" className="flex items-center gap-2 cursor-pointer font-normal">
                  <Mail className="h-4 w-4 text-blue-600" />
                  <span>Enviar lembrete por E-mail</span>
                </Label>
              </div>
            </div>
          </div>

          {/* Validação de cobertura - Alerta de sucesso */}
          {paymentType === "convenio" && insuranceProvider && service && coverageCheck.covered && coverageCheck.message && (
            <Alert className="border-green-200 bg-green-50">
              <CheckCircle2 className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-700">
                {coverageCheck.message}
              </AlertDescription>
            </Alert>
          )}

          {/* Validação de cobertura - Alerta de erro */}
          {hasCoverageIssue && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                {coverageCheck.message}
              </AlertDescription>
            </Alert>
          )}

          <Button type="submit" className="w-full" disabled={!isFormValid}>
            Confirmar Agendamento
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}