import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Label } from "./ui/label";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Checkbox } from "./ui/checkbox";
import { Shield, Building2, Trash2, CheckCircle2 } from "lucide-react";

export interface HealthInsurance {
  id: string;
  name: string;
  coverageTypes: string[];
}

interface HealthInsuranceRegistrationProps {
  insurances: HealthInsurance[];
  onRegister: (insurance: Omit<HealthInsurance, "id">) => void;
  onDelete: (id: string) => void;
}

const COVERAGE_TYPES = [
  { id: "ambulatorial", label: "Ambulatorial" },
  { id: "hospitalar", label: "Hospitalar (com internação)" },
  { id: "obstetricia", label: "Obstétrico (parto)" },
  { id: "odontologico", label: "Odontológico" },
  { id: "urgencia", label: "Urgência e Emergência" },
  { id: "laboratorio", label: "Exames Laboratoriais" },
  { id: "imagem", label: "Exames de Imagem" },
  { id: "terapias", label: "Terapias (Fisioterapia, Psicologia, etc.)" },
  { id: "home_care", label: "Home Care (atendimento domiciliar)" },
  { id: "referencia", label: "Cobertura Nacional (livre escolha)" },
];

export function HealthInsuranceRegistration({
  insurances,
  onRegister,
  onDelete,
}: HealthInsuranceRegistrationProps) {
  const [name, setName] = useState("");
  const [selectedCoverages, setSelectedCoverages] = useState<string[]>([]);

  const handleToggleCoverage = (coverageId: string) => {
    setSelectedCoverages((prev) =>
      prev.includes(coverageId)
        ? prev.filter((id) => id !== coverageId)
        : [...prev, coverageId]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim()) {
      alert("Por favor, informe o nome do plano");
      return;
    }

    if (selectedCoverages.length === 0) {
      alert("Por favor, selecione pelo menos um tipo de cobertura");
      return;
    }

    const existingInsurance = insurances.find(
      (ins) => ins.name.toLowerCase() === name.toLowerCase()
    );

    if (existingInsurance) {
      alert("Já existe um plano cadastrado com este nome");
      return;
    }

    onRegister({
      name: name.trim(),
      coverageTypes: selectedCoverages,
    });

    // Limpar formulário
    setName("");
    setSelectedCoverages([]);
  };

  const getCoverageLabel = (coverageId: string) => {
    return COVERAGE_TYPES.find((c) => c.id === coverageId)?.label || coverageId;
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Cadastro de Planos de Saúde</CardTitle>
          <CardDescription>
            Registre os planos de saúde aceitos pela clínica
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="insurance-name">Nome do Plano *</Label>
              <div className="relative">
                <Building2 className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="insurance-name"
                  type="text"
                  placeholder="Ex: Bradesco Saúde, Unimed, SulAmérica, etc."
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-muted-foreground" />
                <Label>Tipos de Cobertura *</Label>
              </div>
              <p className="text-sm text-muted-foreground">
                Selecione todas as coberturas oferecidas por este plano
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 p-4 border rounded-lg bg-slate-50">
                {COVERAGE_TYPES.map((coverage) => (
                  <div key={coverage.id} className="flex items-start space-x-3">
                    <Checkbox
                      id={coverage.id}
                      checked={selectedCoverages.includes(coverage.id)}
                      onCheckedChange={() => handleToggleCoverage(coverage.id)}
                    />
                    <label
                      htmlFor={coverage.id}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                    >
                      {coverage.label}
                    </label>
                  </div>
                ))}
              </div>
              {selectedCoverages.length > 0 && (
                <div className="flex items-center gap-2 text-sm text-green-600">
                  <CheckCircle2 className="h-4 w-4" />
                  <span>
                    {selectedCoverages.length}{" "}
                    {selectedCoverages.length === 1 ? "cobertura selecionada" : "coberturas selecionadas"}
                  </span>
                </div>
              )}
            </div>

            <Button type="submit" className="w-full">
              Cadastrar Plano de Saúde
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Planos Cadastrados</CardTitle>
          <CardDescription>
            {insurances.length === 0
              ? "Nenhum plano de saúde cadastrado ainda"
              : `${insurances.length} plano(s) cadastrado(s)`}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {insurances.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                Nenhum plano de saúde cadastrado ainda
              </div>
            ) : (
              insurances.map((insurance) => (
                <div
                  key={insurance.id}
                  className="flex items-start justify-between p-4 border rounded-lg bg-background"
                >
                  <div className="space-y-2 flex-1">
                    <div className="flex items-center gap-2">
                      <Building2 className="h-4 w-4 text-muted-foreground" />
                      <span className="font-medium text-lg">{insurance.name}</span>
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Shield className="h-3 w-3" />
                        <span className="font-medium">Coberturas:</span>
                      </div>
                      <div className="flex flex-wrap gap-2 ml-5">
                        {insurance.coverageTypes.map((coverageId) => (
                          <span
                            key={coverageId}
                            className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-blue-50 text-blue-700 border border-blue-200"
                            style={{ fontSize: "0.75rem" }}
                          >
                            <CheckCircle2 className="h-3 w-3" />
                            {getCoverageLabel(coverageId)}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onDelete(insurance.id)}
                    className="text-destructive hover:text-destructive ml-2"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
