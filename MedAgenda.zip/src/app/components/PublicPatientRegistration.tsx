import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Label } from "./ui/label";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { User, Mail, Phone, CreditCard, Calendar, Lock, Eye, EyeOff, CalendarCheck, ArrowLeft, CheckCircle2, AlertCircle, Shield } from "lucide-react";
import { Patient } from "./PatientRegistration";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Switch } from "./ui/switch";

interface PublicPatientRegistrationProps {
  patients: Patient[];
  onRegister: (patient: Omit<Patient, "id">) => void;
  onBack: () => void;
  healthInsurances: Array<{ name: string }>;
}

export function PublicPatientRegistration({ patients, onRegister, onBack, healthInsurances }: PublicPatientRegistrationProps) {
  const [cpf, setCpf] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [birthDate, setBirthDate] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [hasHealthInsurance, setHasHealthInsurance] = useState(false);
  const [healthInsuranceName, setHealthInsuranceName] = useState("");
  const [healthInsuranceCardNumber, setHealthInsuranceCardNumber] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const formatCPF = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    if (numbers.length <= 11) {
      return numbers
        .replace(/(\d{3})(\d)/, "$1.$2")
        .replace(/(\d{3})(\d)/, "$1.$2")
        .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
    }
    return cpf;
  };

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    if (numbers.length <= 10) {
      // Telefone fixo: (00) 0000-0000
      return numbers
        .replace(/(\d{2})(\d)/, "($1) $2")
        .replace(/(\d{4})(\d)/, "$1-$2");
    } else if (numbers.length <= 11) {
      // Celular: (00) 00000-0000
      return numbers
        .replace(/(\d{2})(\d)/, "($1) $2")
        .replace(/(\d{5})(\d)/, "$1-$2");
    }
    // Limita a 11 dígitos
    return formatPhone(numbers.slice(0, 11));
  };

  const validateEmail = (email: string) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    // Validação do nome
    if (name.trim().split(" ").length < 2) {
      setError("Por favor, insira o nome completo (nome e sobrenome)");
      return;
    }

    // Validação do CPF (obrigatório)
    const cpfNumbers = cpf.replace(/\D/g, "");
    if (cpfNumbers.length !== 11) {
      setError("CPF inválido. Deve conter 11 dígitos");
      return;
    }

    const existingPatient = patients.find(p => p.cpf === cpf);
    if (existingPatient) {
      setError("Já existe um paciente cadastrado com este CPF");
      return;
    }

    // Validação do email
    if (!validateEmail(email)) {
      setError("Por favor, insira um email válido");
      return;
    }

    // Validação do telefone
    const phoneNumbers = phone.replace(/\D/g, "");
    if (phoneNumbers.length < 10) {
      setError("Telefone inválido. Deve conter no mínimo 10 dígitos");
      return;
    }

    // Validação da data de nascimento
    if (!birthDate) {
      setError("Por favor, informe sua data de nascimento");
      return;
    }

    const birthDateObj = new Date(birthDate);
    const today = new Date();
    const age = today.getFullYear() - birthDateObj.getFullYear();
    if (age < 0 || age > 150) {
      setError("Data de nascimento inválida");
      return;
    }

    // Validação da senha
    if (password.length < 6) {
      setError("A senha deve ter no mínimo 6 caracteres");
      return;
    }

    if (password !== confirmPassword) {
      setError("As senhas não coincidem");
      return;
    }

    onRegister({
      cpf,
      name,
      email,
      phone,
      birthDate,
      password,
      hasHealthInsurance,
      healthInsuranceName,
      healthInsuranceCardNumber,
    });

    // Mostra mensagem de sucesso
    setSuccess(true);

    // Limpar formulário após 3 segundos e voltar para login
    setTimeout(() => {
      setCpf("");
      setName("");
      setEmail("");
      setPhone("");
      setBirthDate("");
      setPassword("");
      setConfirmPassword("");
      setSuccess(false);
      onBack();
    }, 3000);
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-gradient-to-br from-slate-50 to-blue-50">
        <Card className="w-full max-w-md border-0 shadow-xl">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle2 className="h-8 w-8 text-green-600" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-green-700">Cadastro Realizado!</h2>
                <p className="text-muted-foreground mt-2">
                  Seu cadastro foi concluído com sucesso. Você já pode fazer login e agendar suas consultas.
                </p>
              </div>
              <div className="pt-4">
                <div className="animate-spin mx-auto h-6 w-6 border-2 border-green-600 border-t-transparent rounded-full"></div>
                <p className="text-sm text-muted-foreground mt-2">
                  Redirecionando para login...
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex">
      {/* Painel esquerdo */}
      <div
        className="hidden lg:flex lg:w-1/2 relative flex-col justify-between p-12 text-white overflow-hidden"
        style={{ background: "linear-gradient(135deg, #1e3a5f 0%, #2563eb 50%, #1d4ed8 100%)" }}
      >
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url(https://images.unsplash.com/photo-1758101512269-660feabf64fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwY2xpbmljJTIwaG9zcGl0YWwlMjBtb2Rlcm4lMjBpbnRlcmlvcnxlbnwxfHx8fDE3NzI1NTU1Njd8MA&ixlib=rb-4.1.0&q=80&w=1080)`,
            opacity: 0.15,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/80 via-blue-700/70 to-indigo-800/80" />

        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-white/20 p-2 rounded-xl backdrop-blur-sm">
              <CalendarCheck className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-white" style={{ fontSize: "1.5rem", fontWeight: 700 }}>
                MedAgenda
              </h1>
              <p className="text-blue-200" style={{ fontSize: "0.875rem" }}>
                Sistema de agendamento médico
              </p>
            </div>
          </div>
        </div>

        <div className="relative z-10 space-y-8">
          <div>
            <h2
              className="text-white mb-3"
              style={{ fontSize: "2rem", fontWeight: 700, lineHeight: 1.2 }}
            >
              Cadastre-se e agende sua consulta
            </h2>
            <p className="text-blue-200" style={{ fontSize: "1rem", lineHeight: 1.6 }}>
              Preencha seus dados para criar sua conta e ter acesso ao sistema de agendamento online.
            </p>
          </div>

          <div className="space-y-4">
            {[
              "Cadastro rápido e seguro",
              "Agende consultas 24 horas por dia",
              "Escolha data, horário e médico",
              "Acompanhe seu histórico de consultas",
            ].map((feature, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-blue-400/30 flex items-center justify-center flex-shrink-0">
                  <div className="w-2 h-2 rounded-full bg-blue-200" />
                </div>
                <span className="text-blue-100" style={{ fontSize: "0.9rem" }}>
                  {feature}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="relative z-10">
          <p className="text-blue-300" style={{ fontSize: "0.75rem" }}>
            © 2026 MedAgenda · Todos os direitos reservados
          </p>
        </div>
      </div>

      {/* Painel direito */}
      <div className="flex-1 flex items-center justify-center p-6 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="w-full max-w-md space-y-6">
          {/* Logo mobile */}
          <div className="flex lg:hidden items-center justify-center gap-2 mb-4">
            <div className="bg-blue-600 p-2 rounded-xl">
              <CalendarCheck className="h-7 w-7 text-white" />
            </div>
            <p className="text-blue-700" style={{ fontSize: "1.25rem", fontWeight: 700 }}>
              MedAgenda
            </p>
          </div>

          <Card
            className="border-0 shadow-xl"
            style={{ background: "rgba(255,255,255,0.95)", backdropFilter: "blur(10px)" }}
          >
            <CardHeader className="pb-2 text-center">
              <div className="mx-auto w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center mb-3 shadow-lg">
                <User className="h-7 w-7 text-white" />
              </div>
              <CardTitle style={{ fontSize: "1.5rem", fontWeight: 700 }}>
                Cadastro de Paciente
              </CardTitle>
              <CardDescription>
                Preencha seus dados para criar sua conta
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-4">
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome Completo *</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="name"
                      type="text"
                      placeholder="Digite seu nome completo"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="seu@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Telefone *</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="(00) 00000-0000"
                      value={phone}
                      onChange={(e) => setPhone(formatPhone(e.target.value))}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="birthDate">Data de Nascimento *</Label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="birthDate"
                      type="date"
                      value={birthDate}
                      onChange={(e) => setBirthDate(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cpf">CPF *</Label>
                  <div className="relative">
                    <CreditCard className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="cpf"
                      type="text"
                      placeholder="000.000.000-00"
                      value={cpf}
                      onChange={(e) => setCpf(formatCPF(e.target.value))}
                      className="pl-10"
                      maxLength={14}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Senha *</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Mínimo 6 caracteres"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10 pr-10"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                      tabIndex={-1}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirmar Senha *</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="confirmPassword"
                      type={showConfirmPassword ? "text" : "password"}
                      placeholder="Digite a senha novamente"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="pl-10 pr-10"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                      tabIndex={-1}
                    >
                      {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between p-4 border rounded-lg bg-muted/50">
                    <div className="flex items-center gap-3">
                      <Shield className="h-5 w-5 text-muted-foreground" />
                      <div>
                        <Label htmlFor="hasHealthInsurance" className="cursor-pointer">
                          Possui Plano de Saúde?
                        </Label>
                        <p className="text-sm text-muted-foreground">
                          Selecione se você possui convênio médico
                        </p>
                      </div>
                    </div>
                    <Switch
                      id="hasHealthInsurance"
                      checked={hasHealthInsurance}
                      onCheckedChange={(checked) => {
                        setHasHealthInsurance(checked);
                        if (!checked) setHealthInsuranceName("");
                      }}
                    />
                  </div>
                </div>

                {hasHealthInsurance && (
                  <div className="space-y-2">
                    <Label htmlFor="healthInsuranceName">Selecione o Convênio *</Label>
                    <Select
                      value={healthInsuranceName}
                      onValueChange={(value) => setHealthInsuranceName(value)}
                    >
                      <SelectTrigger id="healthInsuranceName">
                        <SelectValue placeholder="Escolha o plano de saúde" />
                      </SelectTrigger>
                      <SelectContent>
                        {healthInsurances.map((insurance) => (
                          <SelectItem key={insurance.name} value={insurance.name}>
                            {insurance.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {hasHealthInsurance && (
                  <div className="space-y-2">
                    <Label htmlFor="healthInsuranceCardNumber">Número da Carteirinha</Label>
                    <div className="relative">
                      <CreditCard className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="healthInsuranceCardNumber"
                        type="text"
                        placeholder="Digite o número da carteirinha"
                        value={healthInsuranceCardNumber}
                        onChange={(e) => setHealthInsuranceCardNumber(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                )}

                {error && (
                  <div className="flex items-center gap-2 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700">
                    <AlertCircle className="h-4 w-4 flex-shrink-0" />
                    <p style={{ fontSize: "0.875rem" }}>{error}</p>
                  </div>
                )}

                <Button
                  type="submit"
                  className="w-full"
                  style={{
                    background: "linear-gradient(135deg, #2563eb, #1d4ed8)",
                    height: "2.75rem",
                  }}
                >
                  Criar Conta
                </Button>

                <Button
                  type="button"
                  variant="outline"
                  onClick={onBack}
                  className="w-full flex items-center gap-2"
                >
                  <ArrowLeft className="h-4 w-4" />
                  Voltar para Login
                </Button>
              </form>
            </CardContent>
          </Card>

          <p className="text-center text-muted-foreground" style={{ fontSize: "0.75rem" }}>
            Ao se cadastrar, você concorda com nossos termos de uso e política de privacidade
          </p>
        </div>
      </div>
    </div>
  );
}