import { useState, useEffect } from "react";
import { format, getDay } from "date-fns";
import { ptBR } from "date-fns/locale";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { RadioGroup, RadioGroupItem } from "./ui/radio-group";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Calendar } from "./ui/calendar";
import { Alert, AlertDescription } from "./ui/alert";
import { Calendar as CalendarIcon, Save, AlertTriangle } from "lucide-react";
import { Doctor } from "./DoctorRegistration";

const TIME_SLOTS = [
  "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "10:30", 
  "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30",
  "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30",
  "19:00", "19:30", "20:00"
];

const SERVICES = [
  "Consulta Geral",
  "Avaliação",
  "Retorno",
  "Exame",
  "Procedimento",
];

const INSURANCE_PROVIDERS = ["Bradesco", "Unimed", "Sulamerica", "Petrobras"];

export interface Appointment {
  id: string;
  cpf: string;
  name: string;
  email: string;
  phone: string;
  date: Date;
  time: string;
  service: string;
  paymentType: string;
  specialty: string;
  doctor: string;
  insuranceProvider?: string;
  consultationPrice?: string;
  observations?: string;
  completed?: boolean;
  reminderWhatsApp?: boolean;
  reminderEmail?: boolean;
}

interface EditAppointmentModalProps {
  appointment: Appointment | null;
  open: boolean;
  onClose: () => void;
  onSave: (updated: Appointment) => void;
  bookedSlots: { date: Date; time: string; doctor: string }[];
  doctors: Doctor[];
}

export function EditAppointmentModal({
  appointment,
  open,
  onClose,
  onSave,
  bookedSlots,
  doctors,
}: EditAppointmentModalProps) {
  const [date, setDate] = useState<Date | undefined>();
  const [time, setTime] = useState("");
  const [service, setService] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [doctor, setDoctor] = useState("");
  const [paymentType, setPaymentType] = useState("");
  const [insuranceProvider, setInsuranceProvider] = useState("");
  const [consultationPrice, setConsultationPrice] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [observations, setObservations] = useState("");

  // Mapeia número do dia da semana para nome
  const getDayName = (dayNumber: number): string => {
    const days = ["Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado"];
    return days[dayNumber];
  };

  // Verifica se o médico atende no dia da semana selecionado
  const isDoctorAvailableOnDay = (doctorName: string, selectedDate: Date): boolean => {
    const selectedDoctor = doctors.find(d => d.name === doctorName);
    if (!selectedDoctor || !selectedDoctor.availability || selectedDoctor.availability.length === 0) {
      return true; // Se não há disponibilidade configurada, permite agendar
    }
    
    const dayOfWeek = getDayName(getDay(selectedDate));
    return selectedDoctor.availability.some(avail => avail.dayOfWeek === dayOfWeek);
  };

  // Verifica se o horário está dentro da disponibilidade do médico
  const isTimeInDoctorAvailability = (doctorName: string, selectedDate: Date, selectedTime: string): boolean => {
    const selectedDoctor = doctors.find(d => d.name === doctorName);
    if (!selectedDoctor || !selectedDoctor.availability || selectedDoctor.availability.length === 0) {
      return true; // Se não há disponibilidade configurada, permite agendar
    }
    
    const dayOfWeek = getDayName(getDay(selectedDate));
    const availability = selectedDoctor.availability.find(avail => avail.dayOfWeek === dayOfWeek);
    
    if (!availability) return false;
    
    // Converte strings de horário para minutos para comparação
    const timeToMinutes = (time: string) => {
      const [hours, minutes] = time.split(':').map(Number);
      return hours * 60 + minutes;
    };
    
    const selectedMinutes = timeToMinutes(selectedTime);
    const startMinutes = timeToMinutes(availability.startTime);
    const endMinutes = timeToMinutes(availability.endTime);
    
    return selectedMinutes >= startMinutes && selectedMinutes <= endMinutes;
  };

  // Filtra horários disponíveis baseado na disponibilidade do médico
  const getAvailableTimeSlots = (): string[] => {
    if (!date || !doctor) return TIME_SLOTS;
    
    const selectedDoctor = doctors.find(d => d.name === doctor);
    if (!selectedDoctor || !selectedDoctor.availability || selectedDoctor.availability.length === 0) {
      return TIME_SLOTS; // Se não há disponibilidade configurada, mostra todos os horários
    }
    
    const dayOfWeek = getDayName(getDay(date));
    const availability = selectedDoctor.availability.find(avail => avail.dayOfWeek === dayOfWeek);
    
    if (!availability) return []; // Se médico não atende neste dia, não mostra horários
    
    // Filtra horários que estão dentro do período de atendimento
    const timeToMinutes = (time: string) => {
      const [hours, minutes] = time.split(':').map(Number);
      return hours * 60 + minutes;
    };
    
    const startMinutes = timeToMinutes(availability.startTime);
    const endMinutes = timeToMinutes(availability.endTime);
    
    return TIME_SLOTS.filter(slot => {
      const slotMinutes = timeToMinutes(slot);
      return slotMinutes >= startMinutes && slotMinutes <= endMinutes;
    });
  };

  const availableSlots = getAvailableTimeSlots();

  // Preenche os campos quando o modal abre
  useEffect(() => {
    if (appointment) {
      setDate(new Date(appointment.date));
      setTime(appointment.time);
      setService(appointment.service);
      setSpecialty(appointment.specialty);
      setDoctor(appointment.doctor);
      setPaymentType(appointment.paymentType);
      setInsuranceProvider(appointment.insuranceProvider ?? "");
      setConsultationPrice(appointment.consultationPrice ?? "");
      setName(appointment.name);
      setEmail(appointment.email);
      setPhone(appointment.phone);
      setObservations(appointment.observations ?? "");
    }
  }, [appointment]);

  const isSlotBooked = (slot: string) => {
    if (!date || !appointment) return false;
    // Ignora o próprio horário original da consulta em edição
    return bookedSlots.some(
      (b) =>
        format(b.date, "yyyy-MM-dd") === format(date, "yyyy-MM-dd") &&
        b.time === slot &&
        b.doctor === doctor &&
        !(
          format(new Date(appointment.date), "yyyy-MM-dd") === format(date, "yyyy-MM-dd") &&
          appointment.time === slot &&
          appointment.doctor === doctor
        )
    );
  };

  const isFormValid =
    date &&
    time &&
    service &&
    specialty &&
    doctor &&
    paymentType &&
    name &&
    email &&
    phone &&
    ((paymentType === "convenio" && insuranceProvider) ||
      (paymentType === "particular" && consultationPrice));

  const handleSave = () => {
    if (!appointment || !date || !isFormValid) return;
    onSave({
      ...appointment,
      date,
      time,
      service,
      specialty,
      doctor,
      paymentType,
      name,
      email,
      phone,
      insuranceProvider: paymentType === "convenio" ? insuranceProvider : undefined,
      consultationPrice: paymentType === "particular" ? consultationPrice : undefined,
      observations,
    });
    onClose();
  };

  // Obter lista única de especialidades
  const specialties = Array.from(new Set(doctors.map(d => d.specialty))).sort();

  // Filtrar médicos por especialidade
  const filteredDoctors = specialty 
    ? doctors.filter(d => d.specialty === specialty)
    : [];

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Editar Consulta</DialogTitle>
          <DialogDescription>
            Altere os dados do agendamento e salve as mudanças.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Nome */}
          <div className="space-y-2">
            <Label htmlFor="edit-name">Nome Completo</Label>
            <Input
              id="edit-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Nome do paciente"
            />
          </div>

          {/* E-mail */}
          <div className="space-y-2">
            <Label htmlFor="edit-email">E-mail</Label>
            <Input
              id="edit-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="email@exemplo.com"
            />
          </div>

          {/* Telefone */}
          <div className="space-y-2">
            <Label htmlFor="edit-phone">Telefone</Label>
            <Input
              id="edit-phone"
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="(00) 00000-0000"
            />
          </div>

          {/* Tipo de atendimento */}
          <div className="space-y-2">
            <Label>Tipo de Atendimento</Label>
            <RadioGroup
              value={paymentType}
              onValueChange={(v) => {
                setPaymentType(v);
                setInsuranceProvider("");
                setConsultationPrice("");
              }}
              className="flex gap-6"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="particular" id="edit-particular" />
                <Label htmlFor="edit-particular" className="cursor-pointer">Particular</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="convenio" id="edit-convenio" />
                <Label htmlFor="edit-convenio" className="cursor-pointer">Convênio</Label>
              </div>
            </RadioGroup>
          </div>

          {/* Convênio */}
          {paymentType === "convenio" && (
            <div className="space-y-2">
              <Label>Convênio</Label>
              <Select value={insuranceProvider} onValueChange={setInsuranceProvider}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o convênio" />
                </SelectTrigger>
                <SelectContent>
                  {INSURANCE_PROVIDERS.map((p) => (
                    <SelectItem key={p} value={p}>{p}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Valor particular */}
          {paymentType === "particular" && (
            <div className="space-y-2">
              <Label htmlFor="edit-price">Valor da Consulta (R$)</Label>
              <Input
                id="edit-price"
                type="number"
                value={consultationPrice}
                onChange={(e) => setConsultationPrice(e.target.value)}
                placeholder="Digite o valor"
              />
            </div>
          )}

          {/* Especialidade */}
          <div className="space-y-2">
            <Label>Especialidade</Label>
            <Select value={specialty} onValueChange={(v) => {
              setSpecialty(v);
              setDoctor(""); // Limpa o médico selecionado ao mudar especialidade
            }}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione a especialidade" />
              </SelectTrigger>
              <SelectContent>
                {specialties.map((s) => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Médico(a) */}
          <div className="space-y-2">
            <Label>Médico(a)</Label>
            <Select
              value={doctor}
              onValueChange={(v) => {
                setDoctor(v);
                setTime(""); // reseta horário ao trocar médica
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione o médico(a)" />
              </SelectTrigger>
              <SelectContent>
                {filteredDoctors.map((d) => (
                  <SelectItem key={d.name} value={d.name}>{d.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Serviço */}
          <div className="space-y-2">
            <Label>Serviço</Label>
            <Select value={service} onValueChange={setService}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o serviço" />
              </SelectTrigger>
              <SelectContent>
                {SERVICES.map((s) => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Data */}
          <div className="space-y-2">
            <Label>Data</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start text-left">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, "PPP", { locale: ptBR }) : "Selecione a data"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={(d) => {
                    setDate(d);
                    setTime(""); // reseta horário ao trocar data
                  }}
                  disabled={(d) => d < new Date(new Date().setHours(0, 0, 0, 0))}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* Horários */}
          {date && doctor && (
            <div className="space-y-2">
              {!isDoctorAvailableOnDay(doctor, date) && (
                <Alert variant="destructive" className="mb-2">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    Este médico não atende às {getDayName(getDay(date))}s. Por favor, selecione outra data ou médico.
                  </AlertDescription>
                </Alert>
              )
              }
              
              {isDoctorAvailableOnDay(doctor, date) && availableSlots.length === 0 && (
                <Alert variant="destructive" className="mb-2">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    Este médico não possui horários de atendimento configurados para {getDayName(getDay(date))}.
                  </AlertDescription>
                </Alert>
              )
              }
              
              <Label>Horário</Label>
              <div className="grid grid-cols-4 gap-2">
                {availableSlots.length > 0 ? (
                  availableSlots.map((slot) => {
                    const booked = isSlotBooked(slot);
                    return (
                      <Button
                        key={slot}
                        type="button"
                        variant={time === slot ? "default" : "outline"}
                        className="w-full"
                        onClick={() => setTime(slot)}
                        disabled={booked}
                      >
                        {slot}
                      </Button>
                    );
                  })
                ) : (
                  <div className="col-span-4 text-center p-4 text-muted-foreground text-sm">
                    Nenhum horário disponível para este dia
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Observações */}
          <div className="space-y-2">
            <Label>Observações</Label>
            <Input
              id="edit-observations"
              value={observations}
              onChange={(e) => setObservations(e.target.value)}
              placeholder="Digite as observações"
            />
          </div>
        </div>

        <DialogFooter className="gap-2 pt-2">
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button
            onClick={handleSave}
            disabled={!isFormValid}
            className="gap-2"
            style={{ background: "linear-gradient(135deg, #2563eb, #1d4ed8)" }}
          >
            <Save className="h-4 w-4" />
            Salvar Alterações
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}