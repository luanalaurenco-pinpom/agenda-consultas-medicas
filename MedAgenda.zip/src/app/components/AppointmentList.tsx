import { format, parseISO, isValid } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Calendar, Clock, Mail, Phone, Trash2, User, Stethoscope, CreditCard, Building2, DollarSign, CalendarIcon, X, Pencil, FileText } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Calendar as CalendarComponent } from "./ui/calendar";
import { useState } from "react";
import { EditAppointmentModal, Appointment } from "./EditAppointmentModal";
import { Doctor } from "./DoctorRegistration";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "./ui/alert-dialog";

interface AppointmentListProps {
  appointments: Appointment[];
  onCancel: (id: string) => void;
  onEdit: (updated: Appointment) => void;
  onToggleComplete: (id: string) => void;
  bookedSlots: { date: Date; time: string; doctor: string }[];
  doctors: Doctor[];
}

export function AppointmentList({ appointments, onCancel, onEdit, onToggleComplete, bookedSlots, doctors }: AppointmentListProps) {
  const [startDate, setStartDate] = useState<Date | undefined>();
  const [endDate, setEndDate] = useState<Date | undefined>();
  const [editingAppointment, setEditingAppointment] = useState<Appointment | null>(null);
  const [deletingAppointmentId, setDeletingAppointmentId] = useState<string | null>(null);

  // Função auxiliar para garantir que temos um Date object válido
  const normalizeDate = (date: Date | string): Date => {
    if (date instanceof Date) {
      return date;
    }
    // Se for string, faz parse considerando timezone local
    if (typeof date === 'string') {
      // Se estiver no formato ISO (yyyy-mm-dd), adiciona horário local
      if (/^\d{4}-\d{2}-\d{2}$/.test(date)) {
        const [year, month, day] = date.split('-').map(Number);
        return new Date(year, month - 1, day);
      }
      // Caso contrário, tenta parseISO
      const parsed = parseISO(date);
      return isValid(parsed) ? parsed : new Date(date);
    }
    return new Date(date);
  };

  // Função para definir atalhos de data
  const setDateShortcut = (shortcut: "today" | "week" | "month") => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    switch (shortcut) {
      case "today":
        setStartDate(today);
        setEndDate(today);
        break;
      case "week":
        const weekStart = new Date(today);
        weekStart.setDate(today.getDate() - today.getDay()); // Domingo
        const weekEnd = new Date(weekStart);
        weekEnd.setDate(weekStart.getDate() + 6); // Sábado
        setStartDate(weekStart);
        setEndDate(weekEnd);
        break;
      case "month":
        const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
        const monthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        setStartDate(monthStart);
        setEndDate(monthEnd);
        break;
    }
  };

  const clearFilter = () => {
    setStartDate(undefined);
    setEndDate(undefined);
  };

  const filteredAppointments = startDate || endDate
    ? appointments.filter((apt) => {
        const aptDate = normalizeDate(apt.date);
        aptDate.setHours(0, 0, 0, 0);
        
        if (startDate && endDate) {
          const start = new Date(startDate);
          start.setHours(0, 0, 0, 0);
          const end = new Date(endDate);
          end.setHours(0, 0, 0, 0);
          return aptDate >= start && aptDate <= end;
        } else if (startDate) {
          const start = new Date(startDate);
          start.setHours(0, 0, 0, 0);
          return aptDate >= start;
        } else if (endDate) {
          const end = new Date(endDate);
          end.setHours(0, 0, 0, 0);
          return aptDate <= end;
        }
        return true;
      })
    : appointments;

  const sortedAppointments = [...filteredAppointments].sort((a, b) => {
    const dateA = normalizeDate(a.date);
    const dateB = normalizeDate(b.date);
    if (dateA.getTime() === dateB.getTime()) {
      return a.time.localeCompare(b.time);
    }
    return dateA.getTime() - dateB.getTime();
  });

  const isPast = (date: Date | string, time: string) => {
    const [hours, minutes] = time.split(':').map(Number);
    const appointmentDate = normalizeDate(date);
    appointmentDate.setHours(hours, minutes, 0, 0);
    return appointmentDate < new Date();
  };

  const handleDeleteConfirm = () => {
    if (deletingAppointmentId) {
      onCancel(deletingAppointmentId);
      setDeletingAppointmentId(null);
    }
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Agendamentos</CardTitle>
          <CardDescription>
            {appointments.length === 0
              ? "Nenhum agendamento realizado ainda"
              : startDate || endDate
              ? `${sortedAppointments.length} agendamento(s) filtrado(s)`
              : `${appointments.length} agendamento(s) registrado(s)`}
          </CardDescription>
          
          {/* Filtros de data */}
          <div className="space-y-3 pt-2">
            {/* Atalhos rápidos */}
            <div className="flex gap-2 flex-wrap">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setDateShortcut("today")}
                className="flex-1 sm:flex-none"
              >
                Hoje
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setDateShortcut("week")}
                className="flex-1 sm:flex-none"
              >
                Esta Semana
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setDateShortcut("month")}
                className="flex-1 sm:flex-none"
              >
                Este Mês
              </Button>
              {(startDate || endDate) && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearFilter}
                  className="flex items-center gap-1"
                >
                  <X className="h-4 w-4" />
                  Limpar
                </Button>
              )}
            </div>

            {/* Seleção de intervalo de datas */}
            <div className="flex gap-2 flex-wrap">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="justify-start text-left flex-1 sm:flex-none">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {startDate ? format(startDate, "dd/MM/yyyy", { locale: ptBR }) : "Data inicial"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <CalendarComponent
                    mode="single"
                    selected={startDate}
                    onSelect={setStartDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>

              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="justify-start text-left flex-1 sm:flex-none">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {endDate ? format(endDate, "dd/MM/yyyy", { locale: ptBR }) : "Data final"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <CalendarComponent
                    mode="single"
                    selected={endDate}
                    onSelect={setEndDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {sortedAppointments.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {startDate || endDate
                  ? "Nenhum agendamento encontrado para este período"
                  : "Nenhum agendamento realizado ainda"}
              </div>
            ) : (
              sortedAppointments.map((appointment) => {
                const past = isPast(appointment.date, appointment.time);
                return (
                  <div
                    key={appointment.id}
                    className={`flex flex-col gap-3 p-4 border rounded-lg ${
                      past ? "opacity-60 bg-muted/30" : "bg-background"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">{appointment.name}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Mail className="h-3 w-3" />
                          <span>{appointment.email}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Phone className="h-3 w-3" />
                          <span>{appointment.phone}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Stethoscope className="h-3 w-3" />
                          <span>{appointment.doctor}</span>
                        </div>
                        {appointment.insuranceProvider && (
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Building2 className="h-3 w-3" />
                            <span>{appointment.insuranceProvider}</span>
                          </div>
                        )}
                        {appointment.consultationPrice && (
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <DollarSign className="h-3 w-3" />
                            <span>R$ {appointment.consultationPrice}</span>
                          </div>
                        )}
                        {appointment.observations && (
                          <div className="flex items-start gap-2 text-sm text-muted-foreground">
                            <FileText className="h-3 w-3 mt-0.5" />
                            <span>{appointment.observations}</span>
                          </div>
                        )}
                      </div>

                      {!past && (
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setEditingAppointment(appointment)}
                            className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                            title="Editar consulta"
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setDeletingAppointmentId(appointment.id)}
                            className="text-destructive hover:text-destructive"
                            title="Cancelar consulta"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-3">
                      <Badge variant="secondary" className="gap-1">
                        <Calendar className="h-3 w-3" />
                        {format(appointment.date, "dd/MM/yyyy", { locale: ptBR })}
                      </Badge>
                      <Badge variant="secondary" className="gap-1">
                        <Clock className="h-3 w-3" />
                        {appointment.time}
                      </Badge>
                      <Badge variant="outline">{appointment.service}</Badge>
                      <Badge
                        variant={appointment.paymentType === "particular" ? "default" : "secondary"}
                        className="gap-1"
                      >
                        <CreditCard className="h-3 w-3" />
                        {appointment.paymentType === "particular" ? "Particular" : "Convênio"}
                      </Badge>
                      {past && <Badge variant="destructive">Expirado</Badge>}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>

      <EditAppointmentModal
        appointment={editingAppointment}
        open={!!editingAppointment}
        onClose={() => setEditingAppointment(null)}
        onSave={onEdit}
        bookedSlots={bookedSlots}
        doctors={doctors}
      />

      <AlertDialog open={!!deletingAppointmentId} onOpenChange={(open) => !open && setDeletingAppointmentId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja cancelar este agendamento? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Confirmar Exclusão
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}