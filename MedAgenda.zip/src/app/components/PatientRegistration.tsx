import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Label } from "./ui/label";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { User, Mail, Phone, CreditCard, Trash2, Calendar, Lock, Eye, EyeOff, Pencil, Search, Shield } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "./ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { ScrollArea } from "./ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Switch } from "./ui/switch";

export interface Patient {
  id: string;
  cpf: string;
  name: string;
  email: string;
  phone: string;
  birthDate: string;
  password: string;
  hasHealthInsurance: boolean;
  healthInsuranceName?: string;
  healthInsuranceCardNumber?: string;
}

interface PatientRegistrationProps {
  patients: Patient[];
  onRegister: (patient: Omit<Patient, "id">) => void;
  onDelete: (id: string) => void;
  onEdit?: (id: string, patient: Omit<Patient, "id">) => void;
  healthInsurances: Array<{ name: string }>;
}

export function PatientRegistration({ patients, onRegister, onDelete, onEdit, healthInsurances }: PatientRegistrationProps) {
  const [cpf, setCpf] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [birthDate, setBirthDate] = useState("");
  const [password, setPassword] = useState("");
  const [hasHealthInsurance, setHasHealthInsurance] = useState(false);
  const [healthInsuranceName, setHealthInsuranceName] = useState("");
  const [healthInsuranceCardNumber, setHealthInsuranceCardNumber] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [deletingPatientId, setDeletingPatientId] = useState<string | null>(null);
  const [editingPatient, setEditingPatient] = useState<Patient | null>(null);
  const [editForm, setEditForm] = useState({
    cpf: "",
    name: "",
    email: "",
    phone: "",
    birthDate: "",
    password: "",
    hasHealthInsurance: false,
    healthInsuranceName: "",
    healthInsuranceCardNumber: "",
  });
  const [showEditPassword, setShowEditPassword] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  const formatCPF = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    if (numbers.length <= 11) {
      return numbers
        .replace(/(\d{3})(\d)/, "$1.$2")
        .replace(/(\d{3})(\d)/, "$1.$2")
        .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
    }
    return cpf;
  };

  const formatPhone = (value: string) => {
    const numbers = value.replace(/\D/g, "");
    if (numbers.length <= 10) {
      // Telefone fixo: (00) 0000-0000
      return numbers
        .replace(/(\d{2})(\d)/, "($1) $2")
        .replace(/(\d{4})(\d)/, "$1-$2");
    } else if (numbers.length <= 11) {
      // Celular: (00) 00000-0000
      return numbers
        .replace(/(\d{2})(\d)/, "($1) $2")
        .replace(/(\d{5})(\d)/, "$1-$2");
    }
    // Limita a 11 dígitos
    return formatPhone(numbers.slice(0, 11));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const cpfNumbers = cpf.replace(/\D/g, "");
    if (cpfNumbers.length !== 11) {
      alert("Por favor, insira um CPF válido");
      return;
    }

    if (password.length < 4) {
      alert("A senha deve ter no mínimo 4 caracteres");
      return;
    }

    const existingPatient = patients.find(p => p.cpf === cpf);
    if (existingPatient) {
      alert("Já existe um paciente cadastrado com este CPF");
      return;
    }

    onRegister({
      cpf,
      name,
      email,
      phone,
      birthDate,
      password,
      hasHealthInsurance,
      healthInsuranceName,
      healthInsuranceCardNumber,
    });

    // Limpar formulário
    setCpf("");
    setName("");
    setEmail("");
    setPhone("");
    setBirthDate("");
    setPassword("");
    setHasHealthInsurance(false);
    setHealthInsuranceName("");
    setHealthInsuranceCardNumber("");
  };

  const handleEditClick = (patient: Patient) => {
    setEditingPatient(patient);
    setEditForm({
      cpf: patient.cpf,
      name: patient.name,
      email: patient.email,
      phone: patient.phone,
      birthDate: patient.birthDate,
      password: patient.password,
      hasHealthInsurance: patient.hasHealthInsurance,
      healthInsuranceName: patient.healthInsuranceName || "",
      healthInsuranceCardNumber: patient.healthInsuranceCardNumber || "",
    });
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!editingPatient || !onEdit) return;

    const cpfNumbers = editForm.cpf.replace(/\D/g, "");
    if (cpfNumbers.length !== 11) {
      alert("Por favor, insira um CPF válido");
      return;
    }

    if (editForm.password.length < 4) {
      alert("A senha deve ter no mínimo 4 caracteres");
      return;
    }

    const existingPatient = patients.find(p => p.cpf === editForm.cpf && p.id !== editingPatient.id);
    if (existingPatient) {
      alert("Já existe outro paciente cadastrado com este CPF");
      return;
    }

    onEdit(editingPatient.id, editForm);
    setEditingPatient(null);
  };

  const handleDeleteConfirm = () => {
    if (deletingPatientId) {
      onDelete(deletingPatientId);
      setDeletingPatientId(null);
    }
  };

  // Buscar paciente por CPF
  const foundPatient = searchTerm ? patients.find((patient) => patient.cpf.includes(searchTerm)) : null;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Cadastro de Pacientes</CardTitle>
          <CardDescription>
            Registre novos pacientes no sistema
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="cpf">CPF *</Label>
              <div className="relative">
                <CreditCard className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="cpf"
                  type="text"
                  placeholder="000.000.000-00"
                  value={cpf}
                  onChange={(e) => setCpf(formatCPF(e.target.value))}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="patient-name">Nome Completo *</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="patient-name"
                  type="text"
                  placeholder="Digite o nome completo"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="birth-date">Data de Nascimento *</Label>
              <div className="relative">
                <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="birth-date"
                  type="date"
                  value={birthDate}
                  onChange={(e) => setBirthDate(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="patient-email">Email *</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="patient-email"
                  type="email"
                  placeholder="email@exemplo.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="patient-phone">Telefone *</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="patient-phone"
                  type="tel"
                  placeholder="(00) 00000-0000"
                  value={phone}
                  onChange={(e) => setPhone(formatPhone(e.target.value))}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="patient-password">Senha *</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="patient-password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Digite a senha"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 pr-10"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between p-4 border rounded-lg bg-muted/50">
                <div className="flex items-center gap-3">
                  <Shield className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <Label htmlFor="has-health-insurance" className="cursor-pointer">
                      Possui Plano de Saúde?
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      Selecione se o paciente possui convênio médico
                    </p>
                  </div>
                </div>
                <Switch
                  id="has-health-insurance"
                  checked={hasHealthInsurance}
                  onCheckedChange={(checked) => {
                    setHasHealthInsurance(checked);
                    if (!checked) setHealthInsuranceName("");
                  }}
                />
              </div>
            </div>

            {hasHealthInsurance && (
              <div className="space-y-2">
                <Label htmlFor="health-insurance-name">Selecione o Convênio *</Label>
                <Select
                  value={healthInsuranceName}
                  onValueChange={(value) => setHealthInsuranceName(value)}
                >
                  <SelectTrigger id="health-insurance-name">
                    <SelectValue placeholder="Escolha o plano de saúde" />
                  </SelectTrigger>
                  <SelectContent>
                    {healthInsurances.map((insurance) => (
                      <SelectItem key={insurance.name} value={insurance.name}>
                        {insurance.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {hasHealthInsurance && (
              <div className="space-y-2">
                <Label htmlFor="health-insurance-card-number">Número da Carteirinha</Label>
                <div className="relative">
                  <CreditCard className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="health-insurance-card-number"
                    type="text"
                    placeholder="Digite o número da carteirinha"
                    value={healthInsuranceCardNumber}
                    onChange={(e) => setHealthInsuranceCardNumber(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
            )}

            <Button type="submit" className="w-full">
              Cadastrar Paciente
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Pacientes Cadastrados</CardTitle>
          <CardDescription>
            {patients.length === 0
              ? "Nenhum paciente cadastrado ainda"
              : `${patients.length} paciente(s) cadastrado(s)`}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {patients.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              Nenhum paciente cadastrado ainda
            </div>
          ) : (
            <div className="space-y-4">
              {/* Campo de busca */}
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Buscar por CPF..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(formatCPF(e.target.value))}
                  className="pl-10"
                />
              </div>

              {/* Lista de pacientes */}
              {foundPatient ? (
                <ScrollArea className="h-[400px]">
                  <div className="space-y-3 pr-4">
                    <div
                      key={foundPatient.id}
                      className="flex items-center justify-between p-4 border rounded-lg bg-background"
                    >
                      <div className="space-y-1 flex-1">
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">{foundPatient.name}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <CreditCard className="h-3 w-3" />
                          <span>{foundPatient.cpf}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          <span>{new Date(foundPatient.birthDate).toLocaleDateString('pt-BR')}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Mail className="h-3 w-3" />
                          <span>{foundPatient.email}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Phone className="h-3 w-3" />
                          <span>{foundPatient.phone}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditClick(foundPatient)}
                          className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                          title="Editar paciente"
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setDeletingPatientId(foundPatient.id)}
                          className="text-destructive hover:text-destructive"
                          title="Excluir paciente"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </ScrollArea>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  Nenhum paciente encontrado
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Dialog de edição */}
      <Dialog open={!!editingPatient} onOpenChange={(open) => !open && setEditingPatient(null)}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Editar Paciente</DialogTitle>
            <DialogDescription>
              Atualize as informações do paciente
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEditSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="edit-cpf">CPF *</Label>
              <div className="relative">
                <CreditCard className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="edit-cpf"
                  type="text"
                  placeholder="000.000.000-00"
                  value={editForm.cpf}
                  onChange={(e) => setEditForm({ ...editForm, cpf: formatCPF(e.target.value) })}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-name">Nome Completo *</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="edit-name"
                  type="text"
                  placeholder="Digite o nome completo"
                  value={editForm.name}
                  onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-birth-date">Data de Nascimento *</Label>
              <div className="relative">
                <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="edit-birth-date"
                  type="date"
                  value={editForm.birthDate}
                  onChange={(e) => setEditForm({ ...editForm, birthDate: e.target.value })}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-email">Email *</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="edit-email"
                  type="email"
                  placeholder="email@exemplo.com"
                  value={editForm.email}
                  onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-phone">Telefone *</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="edit-phone"
                  type="tel"
                  placeholder="(00) 00000-0000"
                  value={editForm.phone}
                  onChange={(e) => setEditForm({ ...editForm, phone: formatPhone(e.target.value) })}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-password">Senha *</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="edit-password"
                  type={showEditPassword ? "text" : "password"}
                  placeholder="Digite a senha"
                  value={editForm.password}
                  onChange={(e) => setEditForm({ ...editForm, password: e.target.value })}
                  className="pl-10 pr-10"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowEditPassword(!showEditPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  tabIndex={-1}
                >
                  {showEditPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between p-4 border rounded-lg bg-muted/50">
                <div className="flex items-center gap-3">
                  <Shield className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <Label htmlFor="edit-has-health-insurance" className="cursor-pointer">
                      Possui Plano de Saúde?
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      Selecione se o paciente possui convênio médico
                    </p>
                  </div>
                </div>
                <Switch
                  id="edit-has-health-insurance"
                  checked={editForm.hasHealthInsurance}
                  onCheckedChange={(checked) => {
                    setEditForm({ ...editForm, hasHealthInsurance: checked });
                    if (!checked) setEditForm({ ...editForm, healthInsuranceName: "" });
                  }}
                />
              </div>
            </div>

            {editForm.hasHealthInsurance && (
              <div className="space-y-2">
                <Label htmlFor="edit-health-insurance-name">Selecione o Convênio *</Label>
                <Select
                  value={editForm.healthInsuranceName}
                  onValueChange={(value) => setEditForm({ ...editForm, healthInsuranceName: value })}
                >
                  <SelectTrigger id="edit-health-insurance-name">
                    <SelectValue placeholder="Escolha o plano de saúde" />
                  </SelectTrigger>
                  <SelectContent>
                    {healthInsurances.map((insurance) => (
                      <SelectItem key={insurance.name} value={insurance.name}>
                        {insurance.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {editForm.hasHealthInsurance && (
              <div className="space-y-2">
                <Label htmlFor="edit-health-insurance-card-number">Número da Carteirinha</Label>
                <div className="relative">
                  <CreditCard className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="edit-health-insurance-card-number"
                    type="text"
                    placeholder="Digite o número da carteirinha"
                    value={editForm.healthInsuranceCardNumber}
                    onChange={(e) => setEditForm({ ...editForm, healthInsuranceCardNumber: e.target.value })}
                    className="pl-10"
                  />
                </div>
              </div>
            )}

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setEditingPatient(null)}>
                Cancelar
              </Button>
              <Button type="submit">
                Salvar Alterações
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Dialog de confirmação de exclusão */}
      <AlertDialog open={!!deletingPatientId} onOpenChange={(open) => !open && setDeletingPatientId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir este paciente? Esta ação não pode ser desfeita e todos os dados do paciente serão removidos permanentemente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Confirmar Exclusão
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}