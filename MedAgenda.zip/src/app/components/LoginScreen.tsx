import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "./ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import {
  CalendarCheck,
  Eye,
  EyeOff,
  Lock,
  User,
  AlertCircle,
  ShieldCheck,
  CreditCard,
  UserCheck,
  Stethoscope,
  Mail,
  CheckCircle2,
} from "lucide-react";
import { Patient } from "./PatientRegistration";
import { Doctor } from "./DoctorRegistration";
import clinicImage from "figma:asset/0af28465b8ea52d45915480fc47273f17754915c.png";

const ADMIN_CREDENTIALS = {
  username: "admin",
  password: "admin123",
};

interface LoginScreenProps {
  onAdminLogin: () => void;
  onPatientLogin: (patient: Patient) => void;
  onDoctorLogin: (doctor: Doctor) => void;
  onRegisterClick: () => void;
  patients: Patient[];
  doctors: Doctor[];
}

function formatCPF(value: string) {
  const numbers = value.replace(/\D/g, "");
  return numbers
    .slice(0, 11)
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
}

export function LoginScreen({ onAdminLogin, onPatientLogin, onDoctorLogin, onRegisterClick, patients, doctors }: LoginScreenProps) {
  const [tab, setTab] = useState<"admin" | "patient" | "doctor">("admin");

  // --- Admin state ---
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [adminError, setAdminError] = useState("");
  const [adminLoading, setAdminLoading] = useState(false);
  const [adminShake, setAdminShake] = useState(false);

  // --- Patient state ---
  const [cpf, setCpf] = useState("");
  const [cpfError, setCpfError] = useState("");
  const [cpfLoading, setCpfLoading] = useState(false);
  const [cpfShake, setCpfShake] = useState(false);
  const [patientPassword, setPatientPassword] = useState("");
  const [showPatientPassword, setShowPatientPassword] = useState(false);

  // --- Forgot Password state ---
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [forgotCpf, setForgotCpf] = useState("");
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotError, setForgotError] = useState("");
  const [forgotSuccess, setForgotSuccess] = useState(false);
  const [recoveredPassword, setRecoveredPassword] = useState("");

  // --- Doctor state ---
  const [crm, setCrm] = useState("");
  const [crmError, setCrmError] = useState("");
  const [crmLoading, setCrmLoading] = useState(false);
  const [crmShake, setCrmShake] = useState(false);
  const [doctorPassword, setDoctorPassword] = useState("");
  const [showDoctorPassword, setShowDoctorPassword] = useState(false);

  const handleAdminSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdminError("");
    setAdminLoading(true);
    await new Promise((r) => setTimeout(r, 800));
    if (username === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password) {
      onAdminLogin();
    } else {
      setAdminError("Usuário ou senha incorretos. Tente novamente.");
      setAdminShake(true);
      setTimeout(() => setAdminShake(false), 500);
    }
    setAdminLoading(false);
  };

  const handlePatientSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setCpfError("");
    setCpfLoading(true);
    await new Promise((r) => setTimeout(r, 700));
    const patient = patients.find((p) => p.cpf === cpf && p.password === patientPassword);
    if (patient) {
      onPatientLogin(patient);
    } else {
      setCpfError("CPF ou senha incorretos. Verifique suas credenciais.");
      setCpfShake(true);
      setTimeout(() => setCpfShake(false), 500);
    }
    setCpfLoading(false);
  };

  const handleDoctorSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setCrmError("");
    setCrmLoading(true);
    await new Promise((r) => setTimeout(r, 700));
    const doctor = doctors.find((d) => d.crm === crm && d.password === doctorPassword);
    if (doctor) {
      onDoctorLogin(doctor);
    } else {
      setCrmError("CRM ou senha incorretos. Verifique suas credenciais.");
      setCrmShake(true);
      setTimeout(() => setCrmShake(false), 500);
    }
    setCrmLoading(false);
  };

  const handleForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setForgotError("");

    // Validar CPF
    const cpfNumbers = forgotCpf.replace(/\D/g, "");
    if (cpfNumbers.length !== 11) {
      setForgotError("Por favor, informe um CPF válido");
      return;
    }

    // Buscar paciente pelo CPF e email
    const patient = patients.find(
      (p) => p.cpf === forgotCpf && p.email.toLowerCase() === forgotEmail.toLowerCase()
    );

    if (patient) {
      setRecoveredPassword(patient.password);
      setForgotSuccess(true);
    } else {
      setForgotError("CPF ou email não encontrados. Verifique os dados informados.");
    }
  };

  const handleCloseForgotPassword = () => {
    setShowForgotPassword(false);
    setForgotCpf("");
    setForgotEmail("");
    setForgotError("");
    setForgotSuccess(false);
    setRecoveredPassword("");
  };

  return (
    <div className="min-h-screen flex">
      {/* Painel esquerdo */}
      <div
        className="hidden lg:flex lg:w-1/2 relative flex-col justify-between p-12 text-white overflow-hidden"
        style={{ background: "linear-gradient(135deg, #dbeafe 0%, #e0f2fe 50%, #dbeafe 100%)" }}
      >
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url(${clinicImage})`,
            opacity: 0.3,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-br from-blue-400/20 via-blue-300/15 to-cyan-400/20" />

        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-2">
            <div className="bg-white/30 p-2 rounded-xl backdrop-blur-sm">
              <CalendarCheck className="h-8 w-8 text-blue-900" />
            </div>
            <div>
              <h1 className="text-blue-900" style={{ fontSize: "1.5rem", fontWeight: 800 }}>
                MedAgenda
              </h1>
              <p className="text-blue-800" style={{ fontSize: "0.875rem", fontWeight: 600 }}>
                Sistema de agendamento médico
              </p>
            </div>
          </div>
        </div>

        <div className="relative z-10 space-y-8">
          <div>
            <h2
              className="text-blue-900 mb-3"
              style={{ fontSize: "2rem", fontWeight: 800, lineHeight: 1.2 }}
            >
              {tab === "admin"
                ? "Bem-vindo ao painel de operação"
                : tab === "doctor"
                ? "Portal do Médico"
                : "Agende sua consulta com facilidade"}
            </h2>
            <p className="text-blue-800" style={{ fontSize: "1rem", lineHeight: 1.6, fontWeight: 500 }}>
              {tab === "admin"
                ? "Gerencie agendamentos, pacientes e toda a operação da clínica em um único lugar."
                : tab === "doctor"
                ? "Acesse sua agenda e acompanhe todas as consultas agendadas para você."
                : "Acesse com seu CPF e agende horários com os melhores profissionais da clínica."}
            </p>
          </div>

          <div className="space-y-4">
            {(tab === "admin"
              ? [
                  "Agendamentos em tempo real por médico",
                  "Cadastro e busca automática de pacientes",
                  "Controle de convênios e consultas particulares",
                ]
              : tab === "doctor"
              ? [
                  "Acesso rápido com seu CRM",
                  "Visualize suas consultas do dia",
                  "Acompanhe todo seu histórico de atendimentos",
                ]
              : [
                  "Acesso rápido com seu CPF",
                  "Escolha data, horário e médico disponível",
                  "Acompanhe seus agendamentos",
                ]
            ).map((feature, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-blue-800/25 flex items-center justify-center flex-shrink-0">
                  <div className="w-2 h-2 rounded-full bg-blue-900" />
                </div>
                <span className="text-blue-900" style={{ fontSize: "0.9rem", fontWeight: 500 }}>
                  {feature}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="relative z-10">
          <p className="text-blue-700" style={{ fontSize: "0.75rem", fontWeight: 500 }}>
            © 2026 MedAgenda · Todos os direitos reservados
          </p>
        </div>
      </div>

      {/* Painel direito */}
      <div className="flex-1 flex items-center justify-center p-6 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="w-full max-w-md space-y-6">
          {/* Logo mobile */}
          <div className="flex lg:hidden items-center justify-center gap-2 mb-4">
            <div className="bg-blue-600 p-2 rounded-xl">
              <CalendarCheck className="h-7 w-7 text-white" />
            </div>
            <p className="text-blue-700" style={{ fontSize: "1.25rem", fontWeight: 700 }}>
              MedAgenda
            </p>
          </div>

          {/* Seletor de tipo de acesso */}
          <div className="flex rounded-xl border bg-white shadow-sm overflow-hidden">
            <button
              type="button"
              onClick={() => setTab("admin")}
              className={`flex-1 flex items-center justify-center gap-2 py-3 transition-all ${
                tab === "admin"
                  ? "text-white"
                  : "bg-white text-muted-foreground hover:bg-slate-50"
              }`}
              style={{ 
                fontSize: "0.9rem", 
                fontWeight: tab === "admin" ? 600 : 400,
                background: tab === "admin" ? "linear-gradient(135deg, #1e3a8a, #1e40af)" : "white"
              }}
            >
              <ShieldCheck className="h-4 w-4" />
              Operador
            </button>
            <button
              type="button"
              onClick={() => setTab("patient")}
              className={`flex-1 flex items-center justify-center gap-2 py-3 transition-all ${
                tab === "patient"
                  ? "text-white"
                  : "bg-white text-muted-foreground hover:bg-slate-50"
              }`}
              style={{ 
                fontSize: "0.9rem", 
                fontWeight: tab === "patient" ? 600 : 400,
                background: tab === "patient" ? "linear-gradient(135deg, #1e3a8a, #1e40af)" : "white"
              }}
            >
              <UserCheck className="h-4 w-4" />
              Paciente
            </button>
            <button
              type="button"
              onClick={() => setTab("doctor")}
              className={`flex-1 flex items-center justify-center gap-2 py-3 transition-all ${
                tab === "doctor"
                  ? "text-white"
                  : "bg-white text-muted-foreground hover:bg-slate-50"
              }`}
              style={{ 
                fontSize: "0.9rem", 
                fontWeight: tab === "doctor" ? 600 : 400,
                background: tab === "doctor" ? "linear-gradient(135deg, #1e3a8a, #1e40af)" : "white"
              }}
            >
              <Stethoscope className="h-4 w-4" />
              Médico
            </button>
          </div>

          {/* Card de login */}
          <Card
            className="border-0 shadow-xl"
            style={{ background: "rgba(255,255,255,0.95)", backdropFilter: "blur(10px)" }}
          >
            {/* ─── ADMIN ─── */}
            {tab === "admin" && (
              <>
                <CardHeader className="text-center">
                  <div className="mx-auto w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center mb-3 shadow-lg">
                    <User className="h-7 w-7 text-white" />
                  </div>
                  <CardTitle style={{ fontSize: "1.5rem", fontWeight: 700 }}>
                    Acesso de Operador
                  </CardTitle>
                  <CardDescription>
                    Entre com suas credenciais de operador
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-4">
                  <form
                    onSubmit={handleAdminSubmit}
                    className="space-y-5"
                    style={adminShake ? { animation: "shake 0.4s ease-in-out" } : {}}
                  >
                    <div className="space-y-2">
                      <Label htmlFor="username">Usuário</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="username"
                          type="text"
                          placeholder="Digite seu usuário"
                          value={username}
                          onChange={(e) => { setUsername(e.target.value); setAdminError(""); }}
                          className="pl-10"
                          autoComplete="username"
                          required
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="password">Senha</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="password"
                          type={showPassword ? "text" : "password"}
                          placeholder="Digite sua senha"
                          value={password}
                          onChange={(e) => { setPassword(e.target.value); setAdminError(""); }}
                          className="pl-10 pr-10"
                          autoComplete="current-password"
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                          tabIndex={-1}
                        >
                          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>
                    {adminError && (
                      <div className="flex items-center gap-2 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700">
                        <AlertCircle className="h-4 w-4 flex-shrink-0" />
                        <p style={{ fontSize: "0.875rem" }}>{adminError}</p>
                      </div>
                    )}
                    <Button
                      type="submit"
                      className="w-full"
                      disabled={adminLoading || !username || !password}
                      style={{
                        background: adminLoading ? "#93c5fd" : "linear-gradient(135deg, #2563eb, #1d4ed8)",
                        height: "2.75rem",
                      }}
                    >
                      {adminLoading ? (
                        <span className="flex items-center gap-2">
                          <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                          </svg>
                          Autenticando...
                        </span>
                      ) : "Entrar"}
                    </Button>
                  </form>
                </CardContent>
              </>
            )}

            {/* ─── PACIENTE ─── */}
            {tab === "patient" && (
              <>
                <CardHeader className="pb-2 text-center">
                  <div className="mx-auto w-14 h-14 bg-teal-500 rounded-2xl flex items-center justify-center mb-3 shadow-lg">
                    <UserCheck className="h-7 w-7 text-white" />
                  </div>
                  <CardTitle style={{ fontSize: "1.5rem", fontWeight: 700 }}>
                    Área do Paciente
                  </CardTitle>
                  <CardDescription>
                    Digite seu CPF para acessar e agendar consultas
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-4">
                  <form
                    onSubmit={handlePatientSubmit}
                    className="space-y-5"
                    style={cpfShake ? { animation: "shake 0.4s ease-in-out" } : {}}
                  >
                    <div className="space-y-2">
                      <Label htmlFor="cpf">CPF</Label>
                      <div className="relative">
                        <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="cpf"
                          type="text"
                          placeholder="000.000.000-00"
                          value={cpf}
                          onChange={(e) => {
                            setCpf(formatCPF(e.target.value));
                            setCpfError("");
                          }}
                          className="pl-10"
                          maxLength={14}
                          required
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="patientPassword">Senha</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="patientPassword"
                          type={showPatientPassword ? "text" : "password"}
                          placeholder="Digite sua senha"
                          value={patientPassword}
                          onChange={(e) => { setPatientPassword(e.target.value); setCpfError(""); }}
                          className="pl-10 pr-10"
                          autoComplete="current-password"
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowPatientPassword(!showPatientPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                          tabIndex={-1}
                        >
                          {showPatientPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                      <div className="text-right">
                        <button
                          type="button"
                          onClick={() => setShowForgotPassword(true)}
                          className="text-sm text-blue-600 hover:text-blue-700 hover:underline transition-colors"
                        >
                          Esqueceu a senha?
                        </button>
                      </div>
                    </div>
                    {cpfError && (
                      <div className="flex items-center gap-2 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700">
                        <AlertCircle className="h-4 w-4 flex-shrink-0" />
                        <p style={{ fontSize: "0.875rem" }}>{cpfError}</p>
                      </div>
                    )}
                    <Button
                      type="submit"
                      className="w-full"
                      disabled={cpfLoading || cpf.length < 14}
                      style={{
                        background: cpfLoading ? "#99f6e4" : "linear-gradient(135deg, #14b8a6, #0d9488)",
                        height: "2.75rem",
                      }}
                    >
                      {cpfLoading ? (
                        <span className="flex items-center gap-2">
                          <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                          </svg>
                          Verificando...
                        </span>
                      ) : "Acessar"}
                    </Button>

                    <div className="pt-2">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={onRegisterClick}
                        className="w-full"
                      >
                        Criar Conta
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </>
            )}

            {/* ─── MÉDICO ─── */}
            {tab === "doctor" && (
              <>
                <CardHeader className="pb-2 text-center">
                  <div className="mx-auto w-14 h-14 bg-green-500 rounded-2xl flex items-center justify-center mb-3 shadow-lg">
                    <Stethoscope className="h-7 w-7 text-white" />
                  </div>
                  <CardTitle style={{ fontSize: "1.5rem", fontWeight: 700 }}>
                    Área do Médico
                  </CardTitle>
                  <CardDescription>
                    Digite seu CRM para acessar e gerenciar suas consultas
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-4">
                  <form
                    onSubmit={handleDoctorSubmit}
                    className="space-y-5"
                    style={crmShake ? { animation: "shake 0.4s ease-in-out" } : {}}
                  >
                    <div className="space-y-2">
                      <Label htmlFor="crm">CRM</Label>
                      <div className="relative">
                        <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="crm"
                          type="text"
                          placeholder="00000000"
                          value={crm}
                          onChange={(e) => {
                            setCrm(e.target.value);
                            setCrmError("");
                          }}
                          className="pl-10"
                          maxLength={8}
                          required
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="doctorPassword">Senha</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          id="doctorPassword"
                          type={showDoctorPassword ? "text" : "password"}
                          placeholder="Digite sua senha"
                          value={doctorPassword}
                          onChange={(e) => { setDoctorPassword(e.target.value); setCrmError(""); }}
                          className="pl-10 pr-10"
                          autoComplete="current-password"
                          required
                        />
                        <button
                          type="button"
                          onClick={() => setShowDoctorPassword(!showDoctorPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                          tabIndex={-1}
                        >
                          {showDoctorPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </div>
                    {crmError && (
                      <div className="flex items-center gap-2 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700">
                        <AlertCircle className="h-4 w-4 flex-shrink-0" />
                        <p style={{ fontSize: "0.875rem" }}>{crmError}</p>
                      </div>
                    )}
                    <Button
                      type="submit"
                      className="w-full"
                      disabled={crmLoading || crm.length < 7}
                      style={{
                        background: crmLoading ? "#bbf7d0" : "linear-gradient(135deg, #22c55e, #16a34a)",
                        height: "2.75rem",
                      }}
                    >
                      {crmLoading ? (
                        <span className="flex items-center gap-2">
                          <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                          </svg>
                          Verificando...
                        </span>
                      ) : "Acessar"}
                    </Button>
                  </form>
                </CardContent>
              </>
            )}
          </Card>

          <p className="text-center text-muted-foreground" style={{ fontSize: "0.75rem" }}>
            {tab === "admin"
              ? "Acesso exclusivo para operadores do sistema"
              : "Seus dados estão protegidos e seguros"}
          </p>
        </div>
      </div>

      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          15% { transform: translateX(-6px); }
          30% { transform: translateX(6px); }
          45% { transform: translateX(-4px); }
          60% { transform: translateX(4px); }
          75% { transform: translateX(-2px); }
          90% { transform: translateX(2px); }
        }
      `}</style>

      {/* Modal de Recuperação de Senha */}
      <Dialog open={showForgotPassword} onOpenChange={setShowForgotPassword}>
        <DialogContent className="sm:max-w-md">
          {!forgotSuccess ? (
            <>
              <DialogHeader>
                <div className="mx-auto w-12 h-12 bg-teal-100 rounded-full flex items-center justify-center mb-3">
                  <Lock className="h-6 w-6 text-teal-600" />
                </div>
                <DialogTitle className="text-center">Recuperar Senha</DialogTitle>
                <DialogDescription className="text-center">
                  Digite seu CPF e email cadastrados para recuperar sua senha
                </DialogDescription>
              </DialogHeader>
              
              <form onSubmit={handleForgotPassword} className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="forgotCpf">CPF</Label>
                  <div className="relative">
                    <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="forgotCpf"
                      type="text"
                      placeholder="000.000.000-00"
                      value={forgotCpf}
                      onChange={(e) => {
                        setForgotCpf(formatCPF(e.target.value));
                        setForgotError("");
                      }}
                      className="pl-10"
                      maxLength={14}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="forgotEmail">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="forgotEmail"
                      type="email"
                      placeholder="seu@email.com"
                      value={forgotEmail}
                      onChange={(e) => {
                        setForgotEmail(e.target.value);
                        setForgotError("");
                      }}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                {forgotError && (
                  <div className="flex items-center gap-2 p-3 rounded-lg bg-red-50 border border-red-200 text-red-700">
                    <AlertCircle className="h-4 w-4 flex-shrink-0" />
                    <p style={{ fontSize: "0.875rem" }}>{forgotError}</p>
                  </div>
                )}

                <div className="flex gap-2 pt-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleCloseForgotPassword}
                    className="flex-1"
                  >
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1"
                    style={{ background: "linear-gradient(135deg, #0d9488, #0f766e)" }}
                  >
                    Recuperar
                  </Button>
                </div>
              </form>
            </>
          ) : (
            <>
              <DialogHeader>
                <div className="mx-auto w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-3">
                  <CheckCircle2 className="h-6 w-6 text-green-600" />
                </div>
                <DialogTitle className="text-center">Senha Recuperada!</DialogTitle>
                <DialogDescription className="text-center">
                  Encontramos sua conta. Anote sua senha:
                </DialogDescription>
              </DialogHeader>

              <div className="mt-4 space-y-4">
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-sm text-muted-foreground mb-1">Sua senha é:</p>
                  <p className="text-2xl font-bold text-green-700 text-center tracking-wider">
                    {recoveredPassword}
                  </p>
                </div>

                <div className="flex items-start gap-2 p-3 rounded-lg bg-blue-50 border border-blue-200">
                  <AlertCircle className="h-4 w-4 text-blue-600 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-blue-700">
                    Anote sua senha em um local seguro. Por questões de segurança, 
                    recomendamos que você altere sua senha após fazer login.
                  </p>
                </div>

                <Button
                  onClick={handleCloseForgotPassword}
                  className="w-full"
                  style={{ background: "linear-gradient(135deg, #0d9488, #0f766e)" }}
                >
                  Voltar para Login
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}