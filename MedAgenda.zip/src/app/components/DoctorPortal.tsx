import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "./ui/card";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Calendar as CalendarComponent } from "./ui/calendar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { useState } from "react";
import { format, isToday, parseISO, isValid } from "date-fns";
import { ptBR } from "date-fns/locale";
import {
  CalendarCheck,
  Calendar,
  Clock,
  User,
  Phone,
  Mail,
  Building2,
  DollarSign,
  FileText,
  CreditCard,
  LogOut,
  Stethoscope,
  ClipboardList,
  Calendar as CalendarIcon,
  CheckCircle2,
  X,
  Activity,
  Hash,
} from "lucide-react";

interface Doctor {
  id: string;
  crm: string;
  name: string;
  specialty: string;
  notes: string;
  password: string;
}

interface Appointment {
  id: string;
  name: string;
  cpf: string;
  phone: string;
  email: string;
  date: Date;
  time: string;
  doctor: string;
  service: string;
  paymentType: "particular" | "convenio";
  insuranceProvider?: string;
  consultationPrice?: string;
  observations?: string;
  completed?: boolean;
}

interface DoctorPortalProps {
  doctor: Doctor;
  appointments: Appointment[];
  onLogout: () => void;
  onToggleComplete: (appointmentId: string) => void;
}

export function DoctorPortal({
  doctor,
  appointments,
  onLogout,
  onToggleComplete,
}: DoctorPortalProps) {
  const [filterDate, setFilterDate] = useState<Date | undefined>();

  // Função auxiliar para garantir que temos um Date object válido
  const normalizeDate = (date: Date | string): Date => {
    if (date instanceof Date) {
      return date;
    }
    // Se for string, faz parse considerando timezone local
    if (typeof date === 'string') {
      // Se estiver no formato ISO (yyyy-mm-dd), adiciona horário local
      if (/^\d{4}-\d{2}-\d{2}$/.test(date)) {
        const [year, month, day] = date.split('-').map(Number);
        return new Date(year, month - 1, day);
      }
      // Caso contrário, tenta parseISO
      const parsed = parseISO(date);
      return isValid(parsed) ? parsed : new Date(date);
    }
    return new Date(date);
  };

  // Filtra apenas os agendamentos deste médico
  const myAppointments = [...appointments]
    .filter((apt) => apt.doctor === doctor.name)
    .sort((a, b) => {
      const dateA = normalizeDate(a.date);
      const dateB = normalizeDate(b.date);
      return dateA.getTime() !== dateB.getTime()
        ? dateA.getTime() - dateB.getTime()
        : a.time.localeCompare(b.time);
    });

  const isPast = (date: Date | string, time: string) => {
    const [h, m] = time.split(":").map(Number);
    const d = normalizeDate(date);
    d.setHours(h, m, 0, 0);
    return d < new Date();
  };

  // Consultas de hoje
  const todayAppointments = myAppointments.filter((apt) => isToday(normalizeDate(apt.date)));
  const todayPending = todayAppointments.filter((a) => !a.completed && !isPast(a.date, a.time));
  const todayCompleted = todayAppointments.filter((a) => a.completed);

  // Aplicar filtro de data se houver (para aba "Todas")
  const filteredAppointments = filterDate
    ? myAppointments.filter(
        (apt) => format(normalizeDate(apt.date), "yyyy-MM-dd") === format(filterDate, "yyyy-MM-dd")
      )
    : myAppointments;

  // Separar consultas por status (para aba "Todas")
  const upcoming = filteredAppointments.filter((a) => !isPast(a.date, a.time) && !a.completed);
  const completed = filteredAppointments.filter((a) => a.completed === true);
  const past = filteredAppointments.filter((a) => isPast(a.date, a.time) && !a.completed);

  // Agrupar por data
  const groupByDate = (apts: Appointment[]) => {
    const grouped: { [key: string]: Appointment[] } = {};
    apts.forEach((apt) => {
      const dateKey = format(normalizeDate(apt.date), "yyyy-MM-dd");
      if (!grouped[dateKey]) grouped[dateKey] = [];
      grouped[dateKey].push(apt);
    });
    return grouped;
  };

  const upcomingGrouped = groupByDate(upcoming);
  const completedGrouped = groupByDate(completed);
  const pastGrouped = groupByDate(past);

  const getStatusBadge = (apt: Appointment) => {
    if (apt.completed) {
      return (
        <Badge variant="default" className="bg-green-600 text-white gap-1">
          <CheckCircle2 className="h-3 w-3" />
          Realizada
        </Badge>
      );
    }
    if (isPast(apt.date, apt.time)) {
      return (
        <Badge variant="destructive" className="gap-1">
          <Clock className="h-3 w-3" />
          Expirada
        </Badge>
      );
    }
    return (
      <Badge variant="secondary" className="gap-1 bg-blue-50 text-blue-700 border-blue-200">
        <Activity className="h-3 w-3" />
        Pendente
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
      {/* Header */}
      <header className="bg-white border-b shadow-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-green-600 p-2 rounded-xl">
              <CalendarCheck className="h-6 w-6 text-white" />
            </div>
            <div>
              <p className="text-green-700" style={{ fontSize: "1.1rem", fontWeight: 700 }}>
                MedAgenda
              </p>
              <p className="text-muted-foreground" style={{ fontSize: "0.75rem" }}>
                Área do Médico
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-green-50 border border-green-100 rounded-lg">
              <Stethoscope className="h-4 w-4 text-green-600" />
              <div className="text-left">
                <span className="text-green-700 block" style={{ fontSize: "0.85rem", fontWeight: 500 }}>
                  {doctor.name}
                </span>
                <span className="text-muted-foreground" style={{ fontSize: "0.7rem" }}>
                  CRM: {doctor.crm}
                </span>
              </div>
            </div>
            <Button
              variant="outline"
              onClick={onLogout}
              className="flex items-center gap-2 border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300"
            >
              <LogOut className="h-4 w-4" />
              <span className="hidden sm:inline">Sair</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Boas-vindas */}
        <div className="mb-8">
          <h1 className="text-3xl" style={{ fontWeight: 700 }}>
            Olá, Dr(a). {doctor.name}!
          </h1>
          <p className="text-muted-foreground mt-1">
            {doctor.specialty} · CRM {doctor.crm}
          </p>
        </div>

        {/* Estatísticas */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardDescription className="flex items-center gap-1">
                <CalendarCheck className="h-3 w-3" />
                Consultas Hoje
              </CardDescription>
              <CardTitle className="text-3xl text-orange-600">
                {todayAppointments.length}
              </CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription className="flex items-center gap-1">
                <Activity className="h-3 w-3" />
                Pendentes Hoje
              </CardDescription>
              <CardTitle className="text-3xl text-blue-600">
                {todayPending.length}
              </CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription className="flex items-center gap-1">
                <CheckCircle2 className="h-3 w-3" />
                Realizadas Hoje
              </CardDescription>
              <CardTitle className="text-3xl text-green-600">
                {todayCompleted.length}
              </CardTitle>
            </CardHeader>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardDescription className="flex items-center gap-1">
                <ClipboardList className="h-3 w-3" />
                Total Agendadas
              </CardDescription>
              <CardTitle className="text-3xl text-purple-600">
                {myAppointments.length}
              </CardTitle>
            </CardHeader>
          </Card>
        </div>

        {/* Tabs de Visualização */}
        <Tabs defaultValue="today" className="w-full">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-6">
            <TabsTrigger value="today" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Agenda do Dia
            </TabsTrigger>
            <TabsTrigger value="all" className="flex items-center gap-2">
              <ClipboardList className="h-4 w-4" />
              Todas as Consultas
            </TabsTrigger>
          </TabsList>

          {/* Aba: Agenda do Dia */}
          <TabsContent value="today">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Calendar className="h-5 w-5 text-green-600" />
                      Consultas de Hoje
                    </CardTitle>
                    <CardDescription className="mt-1">
                      {format(new Date(), "EEEE, dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                    </CardDescription>
                  </div>
                  <Badge variant="outline" className="text-lg px-3 py-1">
                    {todayAppointments.length} {todayAppointments.length === 1 ? "consulta" : "consultas"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                {todayAppointments.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <CalendarCheck className="h-12 w-12 mx-auto mb-3 opacity-30" />
                    <p className="text-lg">Nenhuma consulta agendada para hoje</p>
                    <p className="text-sm mt-1">Aproveite para descansar! 🌟</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {todayAppointments.map((apt, index) => (
                      <div
                        key={apt.id}
                        className={`rounded-lg border p-4 space-y-3 ${
                          apt.completed
                            ? "bg-green-50 border-green-200"
                            : isPast(apt.date, apt.time)
                            ? "bg-muted/30 border-muted"
                            : "bg-white shadow-sm border-blue-200"
                        }`}
                      >
                        {/* Cabeçalho do card */}
                        <div className="flex items-start justify-between">
                          <div className="flex items-center gap-3">
                            <div className="flex items-center justify-center w-8 h-8 rounded-full bg-green-600 text-white font-bold">
                              {index + 1}
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <User className="h-4 w-4 text-green-600" />
                                <span style={{ fontWeight: 600, fontSize: "1.05rem" }}>
                                  {apt.name}
                                </span>
                              </div>
                              <div className="flex items-center gap-2 mt-1">
                                <Clock className="h-3 w-3 text-muted-foreground" />
                                <span className="text-sm text-muted-foreground">{apt.time}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            {getStatusBadge(apt)}
                            {!isPast(apt.date, apt.time) && (
                              <Button
                                size="sm"
                                variant={apt.completed ? "default" : "outline"}
                                className={`h-8 px-3 ${
                                  apt.completed
                                    ? "bg-green-600 hover:bg-green-700 text-white"
                                    : "border-green-200 text-green-600 hover:bg-green-50"
                                }`}
                                onClick={() => onToggleComplete(apt.id)}
                              >
                                <CheckCircle2 className={`h-4 w-4 mr-1 ${apt.completed ? "fill-white" : ""}`} />
                                {apt.completed ? "Realizada" : "Marcar"}
                              </Button>
                            )}
                          </div>
                        </div>

                        {/* Informações do paciente */}
                        <div className="grid md:grid-cols-2 gap-3 text-sm">
                          {apt.cpf && (
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <Hash className="h-3 w-3" />
                              <span>CPF: {apt.cpf}</span>
                            </div>
                          )}
                          {apt.phone && (
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <Phone className="h-3 w-3" />
                              {apt.phone}
                            </div>
                          )}
                          {apt.email && (
                            <div className="flex items-center gap-2 text-muted-foreground md:col-span-2">
                              <Mail className="h-3 w-3" />
                              {apt.email}
                            </div>
                          )}
                        </div>

                        {/* Tipo de consulta */}
                        <div className="flex flex-wrap gap-2">
                          <Badge variant="outline" className="text-xs">
                            {apt.service}
                          </Badge>
                          <Badge
                            variant={apt.paymentType === "particular" ? "default" : "secondary"}
                            className="gap-1 text-xs"
                          >
                            <CreditCard className="h-3 w-3" />
                            {apt.paymentType === "particular" ? "Particular" : "Convênio"}
                          </Badge>
                        </div>

                        {/* Convênio ou valor */}
                        {apt.insuranceProvider && (
                          <div className="flex items-center gap-2 text-sm">
                            <Building2 className="h-4 w-4 text-blue-600" />
                            <span className="font-medium">{apt.insuranceProvider}</span>
                          </div>
                        )}
                        {apt.consultationPrice && (
                          <div className="flex items-center gap-2 text-sm">
                            <DollarSign className="h-4 w-4 text-green-600" />
                            <span className="font-medium">R$ {apt.consultationPrice}</span>
                          </div>
                        )}

                        {/* Observações */}
                        {apt.observations && (
                          <div className="p-3 bg-blue-50 rounded-md border border-blue-100">
                            <div className="flex items-start gap-2">
                              <FileText className="h-4 w-4 text-blue-600 mt-0.5" />
                              <div>
                                <p className="text-xs font-medium text-blue-900 mb-1">Observações:</p>
                                <p className="text-sm text-blue-700">{apt.observations}</p>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Aba: Todas as Consultas */}
          <TabsContent value="all">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <ClipboardList className="h-5 w-5 text-green-600" />
                  <CardTitle>Todas as Consultas</CardTitle>
                </div>
                <CardDescription>
                  {myAppointments.length === 0
                    ? "Nenhuma consulta agendada"
                    : `${upcoming.length} próxima(s) · ${completed.length} realizada(s)`}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {myAppointments.length === 0 ? (
                  <div className="text-center py-10 text-muted-foreground">
                    <CalendarCheck className="h-10 w-10 mx-auto mb-3 opacity-30" />
                    <p>Você ainda não tem consultas agendadas.</p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {/* Filtro por data */}
                    <div className="flex items-center gap-2">
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className="w-full sm:w-auto justify-start gap-2"
                          >
                            <CalendarIcon className="h-4 w-4" />
                            {filterDate ? (
                              format(filterDate, "dd 'de' MMMM 'de' yyyy", { locale: ptBR })
                            ) : (
                              "Filtrar por data"
                            )}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <CalendarComponent
                            mode="single"
                            selected={filterDate}
                            onSelect={setFilterDate}
                            locale={ptBR}
                          />
                        </PopoverContent>
                      </Popover>
                      {filterDate && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setFilterDate(undefined)}
                          className="gap-1"
                        >
                          <X className="h-4 w-4" />
                          Limpar filtro
                        </Button>
                      )}
                    </div>

                    {/* Próximas */}
                    {upcoming.length > 0 && (
                      <div>
                        <p
                          className="text-green-700 mb-4"
                          style={{ fontSize: "0.8rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.05em" }}
                        >
                          Próximas consultas
                        </p>
                        <div className="space-y-4">
                          {Object.entries(upcomingGrouped).map(([dateKey, apts]) => {
                            // Parse do dateKey (yyyy-MM-dd) para Date local
                            const [year, month, day] = dateKey.split('-').map(Number);
                            const groupDate = new Date(year, month - 1, day);
                            
                            return (
                              <div key={dateKey}>
                                <div className="flex items-center gap-2 mb-2">
                                  <Calendar className="h-4 w-4 text-green-600" />
                                  <p className="text-sm" style={{ fontWeight: 600 }}>
                                    {format(groupDate, "EEEE, dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                                  </p>
                                </div>
                                <div className="space-y-2 ml-6">
                                  {apts.map((apt) => (
                                    <AppointmentCard
                                      key={apt.id}
                                      appointment={apt}
                                      past={false}
                                      onToggleComplete={onToggleComplete}
                                    />
                                  ))}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Consultas Realizadas */}
                    {completed.length > 0 && (
                      <div className="mt-6">
                        <p
                          className="text-green-600 mb-4"
                          style={{ fontSize: "0.8rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.05em" }}
                        >
                          Consultas Realizadas
                        </p>
                        <div className="space-y-4">
                          {Object.entries(completedGrouped).map(([dateKey, apts]) => {
                            // Parse do dateKey (yyyy-MM-dd) para Date local
                            const [year, month, day] = dateKey.split('-').map(Number);
                            const groupDate = new Date(year, month - 1, day);
                            
                            return (
                              <div key={dateKey}>
                                <div className="flex items-center gap-2 mb-2">
                                  <Calendar className="h-4 w-4 text-green-600" />
                                  <p className="text-sm" style={{ fontWeight: 600 }}>
                                    {format(groupDate, "EEEE, dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                                  </p>
                                </div>
                                <div className="space-y-2 ml-6">
                                  {apts.map((apt) => (
                                    <AppointmentCard
                                      key={apt.id}
                                      appointment={apt}
                                      past={false}
                                      onToggleComplete={onToggleComplete}
                                    />
                                  ))}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Expiradas */}
                    {past.length > 0 && (
                      <div className="mt-6">
                        <p
                          className="text-muted-foreground mb-4"
                          style={{ fontSize: "0.8rem", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.05em" }}
                        >
                          Expiradas
                        </p>
                        <div className="space-y-4 opacity-60">
                          {Object.entries(pastGrouped).map(([dateKey, apts]) => {
                            // Parse do dateKey (yyyy-MM-dd) para Date local
                            const [year, month, day] = dateKey.split('-').map(Number);
                            const groupDate = new Date(year, month - 1, day);
                            
                            return (
                              <div key={dateKey}>
                                <div className="flex items-center gap-2 mb-2">
                                  <Calendar className="h-4 w-4 text-muted-foreground" />
                                  <p className="text-sm" style={{ fontWeight: 600 }}>
                                    {format(groupDate, "EEEE, dd 'de' MMMM 'de' yyyy", { locale: ptBR })}
                                  </p>
                                </div>
                                <div className="space-y-2 ml-6">
                                  {apts.map((apt) => (
                                    <AppointmentCard key={apt.id} appointment={apt} past={true} />
                                  ))}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

// Sub-componente de card de agendamento (versão simplificada para aba "Todas")
function AppointmentCard({
  appointment,
  past,
  onToggleComplete,
}: {
  appointment: Appointment;
  past: boolean;
  onToggleComplete?: (appointmentId: string) => void;
}) {
  const isCompleted = appointment.completed || false;

  return (
    <div
      className={`rounded-lg border p-4 space-y-3 ${
        past ? "bg-muted/20" : "bg-white shadow-sm"
      } ${isCompleted ? "border-green-500" : ""}`}
    >
      {/* Paciente + horário + botão de check */}
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2">
          <User className="h-4 w-4 text-green-600" />
          <span style={{ fontWeight: 500 }}>{appointment.name}</span>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="gap-1">
            <Clock className="h-3 w-3" />
            {appointment.time}
          </Badge>
          {!past && onToggleComplete && (
            <Button
              size="sm"
              variant={isCompleted ? "default" : "outline"}
              className={`h-7 px-2 ${
                isCompleted
                  ? "bg-green-600 hover:bg-green-700 text-white"
                  : "border-green-200 text-green-600 hover:bg-green-50"
              }`}
              onClick={() => onToggleComplete(appointment.id)}
              title={isCompleted ? "Marcar como não realizada" : "Marcar como realizada"}
            >
              <CheckCircle2 className={`h-4 w-4 ${isCompleted ? "fill-white" : ""}`} />
            </Button>
          )}
        </div>
      </div>

      {/* Informações do paciente */}
      <div className="space-y-1 text-sm text-muted-foreground">
        {appointment.phone && (
          <div className="flex items-center gap-1">
            <Phone className="h-3 w-3" />
            {appointment.phone}
          </div>
        )}
        {appointment.email && (
          <div className="flex items-center gap-1">
            <Mail className="h-3 w-3" />
            {appointment.email}
          </div>
        )}
      </div>

      {/* Tipo de consulta e serviço */}
      <div className="flex flex-wrap gap-2">
        <Badge variant="outline" className="text-xs">
          {appointment.service}
        </Badge>
        <Badge
          variant={appointment.paymentType === "particular" ? "default" : "secondary"}
          className="gap-1 text-xs"
        >
          <CreditCard className="h-3 w-3" />
          {appointment.paymentType === "particular" ? "Particular" : "Convênio"}
        </Badge>
        {isCompleted && <Badge variant="default" className="text-xs bg-green-600">Realizada</Badge>}
        {past && !isCompleted && <Badge variant="destructive" className="text-xs">Expirada</Badge>}
      </div>

      {/* Convênio ou valor */}
      {appointment.insuranceProvider && (
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <Building2 className="h-3 w-3" />
          {appointment.insuranceProvider}
        </div>
      )}
      {appointment.consultationPrice && (
        <div className="flex items-center gap-1 text-sm text-muted-foreground">
          <DollarSign className="h-3 w-3" />
          R$ {appointment.consultationPrice}
        </div>
      )}
      {appointment.observations && (
        <div className="flex items-start gap-1 text-sm text-muted-foreground">
          <FileText className="h-3 w-3 mt-0.5" />
          {appointment.observations}
        </div>
      )}
    </div>
  );
}