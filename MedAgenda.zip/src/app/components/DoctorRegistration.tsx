import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Label } from "./ui/label";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Button } from "./ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { Switch } from "./ui/switch";
import { UserRound, Award, Stethoscope, FileText, Trash2, Lock, Eye, EyeOff, Calendar, Clock, Plus, X, CheckCircle2, XCircle, Pencil } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";

export interface DoctorAvailability {
  dayOfWeek: string;
  startTime: string;
  endTime: string;
}

export interface Doctor {
  id: string;
  crm: string;
  name: string;
  specialty: string;
  notes: string;
  password: string;
  availability: DoctorAvailability[];
  isActive: boolean;
}

interface DoctorRegistrationProps {
  doctors: Doctor[];
  onRegister: (doctor: Omit<Doctor, "id">) => void;
  onDelete: (id: string) => void;
  onEdit?: (id: string, doctor: Omit<Doctor, "id">) => void;
}

// Lista completa de especialidades médicas
const MEDICAL_SPECIALTIES = [
  "Acupuntura",
  "Alergia e Imunologia",
  "Anestesiologia",
  "Angiologia",
  "Cardiologia",
  "Cirurgia Cardiovascular",
  "Cirurgia da Mão",
  "Cirurgia de Cabeça e Pescoço",
  "Cirurgia do Aparelho Digestivo",
  "Cirurgia Geral",
  "Cirurgia Oncológica",
  "Cirurgia Pediátrica",
  "Cirurgia Plástica",
  "Cirurgia Torácica",
  "Cirurgia Vascular",
  "Clínica Médica",
  "Coloproctologia",
  "Dermatologia",
  "Endocrinologia e Metabologia",
  "Endoscopia",
  "Gastroenterologia",
  "Genética Médica",
  "Geriatria",
  "Ginecologia e Obstetrícia",
  "Hematologia e Hemoterapia",
  "Homeopatia",
  "Infectologia",
  "Mastologia",
  "Medicina de Emergência",
  "Medicina de Família e Comunidade",
  "Medicina do Trabalho",
  "Medicina do Tráfego",
  "Medicina Esportiva",
  "Medicina Física e Reabilitação",
  "Medicina Intensiva",
  "Medicina Legal e Perícia Médica",
  "Medicina Nuclear",
  "Medicina Preventiva e Social",
  "Nefrologia",
  "Neurocirurgia",
  "Neurologia",
  "Nutrologia",
  "Obstetrícia",
  "Oftalmologia",
  "Oncologia Clínica",
  "Ortopedia e Traumatologia",
  "Otorrinolaringologia",
  "Patologia",
  "Patologia Clínica/Medicina Laboratorial",
  "Pediatria",
  "Pneumologia",
  "Psiquiatria",
  "Radiologia e Diagnóstico por Imagem",
  "Radioterapia",
  "Reumatologia",
  "Urologia",
].sort();

export function DoctorRegistration({ doctors, onRegister, onDelete, onEdit }: DoctorRegistrationProps) {
  const [crm, setCrm] = useState("");
  const [name, setName] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [notes, setNotes] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [availability, setAvailability] = useState<DoctorAvailability[]>([]);
  const [isActive, setIsActive] = useState(true);
  
  // Estados para edição
  const [editingDoctor, setEditingDoctor] = useState<Doctor | null>(null);
  const [editForm, setEditForm] = useState({
    crm: "",
    name: "",
    specialty: "",
    notes: "",
    password: "",
    availability: [] as DoctorAvailability[],
    isActive: true,
  });
  const [showEditPassword, setShowEditPassword] = useState(false);

  // Separar médicos ativos e inativos
  const activeDoctors = doctors.filter(d => d.isActive !== false);
  const inactiveDoctors = doctors.filter(d => d.isActive === false);

  const formatCRM = (value: string) => {
    // Remove tudo que não é número
    const numbers = value.replace(/\D/g, "");
    // Limita a 8 dígitos
    return numbers.slice(0, 8);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (crm.length < 4) {
      alert("Por favor, insira um CRM válido");
      return;
    }

    if (password.length < 4) {
      alert("A senha deve ter no mínimo 4 caracteres");
      return;
    }

    const existingDoctor = doctors.find(d => d.crm === crm);
    if (existingDoctor) {
      alert("Já existe um médico cadastrado com este CRM");
      return;
    }

    onRegister({
      crm,
      name,
      specialty,
      notes,
      password,
      availability,
      isActive,
    });

    // Limpar formulário
    setCrm("");
    setName("");
    setSpecialty("");
    setNotes("");
    setPassword("");
    setAvailability([]);
    setIsActive(true);
  };

  const handleAddAvailability = () => {
    setAvailability([...availability, { dayOfWeek: "", startTime: "", endTime: "" }]);
  };

  const handleRemoveAvailability = (index: number) => {
    const newAvailability = availability.filter((_, i) => i !== index);
    setAvailability(newAvailability);
  };

  const handleAvailabilityChange = (index: number, field: keyof DoctorAvailability, value: string) => {
    const newAvailability = availability.map((avail, i) => 
      i === index ? { ...avail, [field]: value } : avail
    );
    setAvailability(newAvailability);
  };

  const handleEdit = (doctor: Doctor) => {
    setEditingDoctor(doctor);
    setEditForm({
      crm: doctor.crm,
      name: doctor.name,
      specialty: doctor.specialty,
      notes: doctor.notes,
      password: doctor.password,
      availability: doctor.availability,
      isActive: doctor.isActive,
    });
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editForm.crm.length < 4) {
      alert("Por favor, insira um CRM válido");
      return;
    }

    if (editForm.password.length < 4) {
      alert("A senha deve ter no mínimo 4 caracteres");
      return;
    }

    const existingDoctor = doctors.find(d => d.crm === editForm.crm && d.id !== editingDoctor?.id);
    if (existingDoctor) {
      alert("Já existe um médico cadastrado com este CRM");
      return;
    }

    if (onEdit && editingDoctor) {
      onEdit(editingDoctor.id, {
        crm: editForm.crm,
        name: editForm.name,
        specialty: editForm.specialty,
        notes: editForm.notes,
        password: editForm.password,
        availability: editForm.availability,
        isActive: editForm.isActive,
      });
    }

    // Limpar formulário
    setEditingDoctor(null);
    setEditForm({
      crm: "",
      name: "",
      specialty: "",
      notes: "",
      password: "",
      availability: [] as DoctorAvailability[],
      isActive: true,
    });
    setShowEditPassword(false);
  };

  const handleEditAvailabilityChange = (index: number, field: keyof DoctorAvailability, value: string) => {
    const newAvailability = editForm.availability.map((avail, i) => 
      i === index ? { ...avail, [field]: value } : avail
    );
    setEditForm({ ...editForm, availability: newAvailability });
  };

  const handleEditAddAvailability = () => {
    setEditForm({ ...editForm, availability: [...editForm.availability, { dayOfWeek: "", startTime: "", endTime: "" }] });
  };

  const handleEditRemoveAvailability = (index: number) => {
    const newAvailability = editForm.availability.filter((_, i) => i !== index);
    setEditForm({ ...editForm, availability: newAvailability });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Cadastro de Médicos</CardTitle>
          <CardDescription>
            Registre novos médicos no sistema
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="crm">Registro do Médico (CRM) *</Label>
              <div className="relative">
                <Award className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="crm"
                  type="text"
                  placeholder="Digite o número do CRM"
                  value={crm}
                  onChange={(e) => setCrm(formatCRM(e.target.value))}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="doctor-name">Nome Completo *</Label>
              <div className="relative">
                <UserRound className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="doctor-name"
                  type="text"
                  placeholder="Digite o nome completo"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="specialty">Especialidade *</Label>
              <div className="relative">
                <Stethoscope className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Select
                  id="specialty"
                  value={specialty}
                  onValueChange={(value) => setSpecialty(value)}
                  className="pl-10"
                  required
                >
                  <SelectTrigger className="pl-10">
                    <SelectValue placeholder="Ex: Cardiologia, Clínico Geral, etc." />
                  </SelectTrigger>
                  <SelectContent>
                    {MEDICAL_SPECIALTIES.map((specialty) => (
                      <SelectItem key={specialty} value={specialty}>
                        {specialty}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Observações</Label>
              <div className="relative">
                <FileText className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Textarea
                  id="notes"
                  placeholder="Informações adicionais sobre o médico, horários de atendimento, etc."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="pl-10 min-h-[100px]"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Senha *</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Digite a senha"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 pr-10"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Disponibilidade de Atendimento</Label>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleAddAvailability}
                  className="gap-2"
                >
                  <Plus className="h-4 w-4" />
                  Adicionar Horário
                </Button>
              </div>
              
              {availability.length === 0 ? (
                <div className="p-6 border-2 border-dashed rounded-lg text-center text-muted-foreground">
                  <Clock className="h-8 w-8 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">Nenhum horário de atendimento cadastrado</p>
                  <p className="text-xs mt-1">Clique em "Adicionar Horário" para definir a disponibilidade</p>
                </div>
              ) : (
                <div className="space-y-3 p-4 border rounded-lg bg-muted/30">
                  {availability.map((avail, index) => (
                    <div key={index} className="flex flex-col sm:flex-row items-start sm:items-center gap-2 p-3 bg-white rounded-md border">
                      <div className="flex items-center gap-2 flex-1">
                        <Calendar className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <Select
                          value={avail.dayOfWeek}
                          onValueChange={(value) => handleAvailabilityChange(index, "dayOfWeek", value)}
                        >
                          <SelectTrigger className="w-[140px]">
                            <SelectValue placeholder="Dia da semana" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Segunda-feira">Segunda-feira</SelectItem>
                            <SelectItem value="Terça-feira">Terça-feira</SelectItem>
                            <SelectItem value="Quarta-feira">Quarta-feira</SelectItem>
                            <SelectItem value="Quinta-feira">Quinta-feira</SelectItem>
                            <SelectItem value="Sexta-feira">Sexta-feira</SelectItem>
                            <SelectItem value="Sábado">Sábado</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="flex items-center gap-2 flex-1">
                        <Clock className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <div className="flex items-center gap-1">
                          <Input
                            type="time"
                            value={avail.startTime}
                            onChange={(e) => handleAvailabilityChange(index, "startTime", e.target.value)}
                            className="w-[110px]"
                            placeholder="Início"
                          />
                          <span className="text-muted-foreground px-1">até</span>
                          <Input
                            type="time"
                            value={avail.endTime}
                            onChange={(e) => handleAvailabilityChange(index, "endTime", e.target.value)}
                            className="w-[110px]"
                            placeholder="Fim"
                          />
                        </div>
                      </div>
                      
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemoveAvailability(index)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between p-4 border rounded-lg bg-muted/30">
                <div className="space-y-1">
                  <Label htmlFor="isActive" className="cursor-pointer">
                    Status do Médico
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    {isActive 
                      ? "Médico ativo e disponível para agendamentos" 
                      : "Médico inativo e indisponível para novos agendamentos"}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-medium">
                    {isActive ? "Ativo" : "Inativo"}
                  </span>
                  <Switch
                    id="isActive"
                    checked={isActive}
                    onCheckedChange={(checked) => setIsActive(checked)}
                  />
                </div>
              </div>
            </div>

            <Button type="submit" className="w-full">
              Cadastrar Médico
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Médicos Ativos</CardTitle>
          <CardDescription>
            {activeDoctors.length === 0
              ? "Nenhum médico ativo ainda"
              : `${activeDoctors.length} médico(s) ativo(s)`}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {activeDoctors.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                Nenhum médico ativo ainda
              </div>
            ) : (
              activeDoctors.map((doctor) => (
                <div
                  key={doctor.id}
                  className="flex items-start justify-between p-4 border rounded-lg bg-background"
                >
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2">
                      <UserRound className="h-4 w-4 text-muted-foreground" />
                      <span className="font-medium">{doctor.name}</span>
                      <Badge className="bg-green-500 hover:bg-green-600">
                        <CheckCircle2 className="h-3 w-3 mr-1" /> Ativo
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Award className="h-3 w-3" />
                      <span>CRM: {doctor.crm}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Stethoscope className="h-3 w-3" />
                      <span>{doctor.specialty}</span>
                    </div>
                    {doctor.notes && (
                      <div className="flex items-start gap-2 text-sm text-muted-foreground mt-2 pt-2 border-t">
                        <FileText className="h-3 w-3 mt-0.5 flex-shrink-0" />
                        <span className="whitespace-pre-wrap">{doctor.notes}</span>
                      </div>
                    )}
                    {doctor.availability && doctor.availability.length > 0 && (
                      <div className="flex items-start gap-2 text-sm text-muted-foreground mt-2 pt-2 border-t">
                        <Calendar className="h-3 w-3 mt-0.5 flex-shrink-0" />
                        <div className="flex flex-wrap gap-1">
                          {doctor.availability.map((avail, idx) => (
                            <Badge key={`${avail.dayOfWeek}-${idx}`} variant="secondary" className="text-xs">
                              {avail.dayOfWeek} {avail.startTime} - {avail.endTime}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-1 ml-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(doctor)}
                      className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                      title="Editar médico"
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onDelete(doctor.id)}
                      className="text-destructive hover:text-destructive"
                      title="Excluir médico"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {inactiveDoctors.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Médicos Inativos</CardTitle>
            <CardDescription>
              {`${inactiveDoctors.length} médico(s) inativo(s)`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {inactiveDoctors.map((doctor) => (
                <div
                  key={doctor.id}
                  className="flex items-start justify-between p-4 border rounded-lg bg-background opacity-75"
                >
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2">
                      <UserRound className="h-4 w-4 text-muted-foreground" />
                      <span className="font-medium">{doctor.name}</span>
                      <Badge variant="secondary" className="bg-gray-400 hover:bg-gray-500">
                        <XCircle className="h-3 w-3 mr-1" /> Inativo
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Award className="h-3 w-3" />
                      <span>CRM: {doctor.crm}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Stethoscope className="h-3 w-3" />
                      <span>{doctor.specialty}</span>
                    </div>
                    {doctor.notes && (
                      <div className="flex items-start gap-2 text-sm text-muted-foreground mt-2 pt-2 border-t">
                        <FileText className="h-3 w-3 mt-0.5 flex-shrink-0" />
                        <span className="whitespace-pre-wrap">{doctor.notes}</span>
                      </div>
                    )}
                    {doctor.availability && doctor.availability.length > 0 && (
                      <div className="flex items-start gap-2 text-sm text-muted-foreground mt-2 pt-2 border-t">
                        <Calendar className="h-3 w-3 mt-0.5 flex-shrink-0" />
                        <div className="flex flex-wrap gap-1">
                          {doctor.availability.map((avail, idx) => (
                            <Badge key={`${avail.dayOfWeek}-${idx}`} variant="secondary" className="text-xs">
                              {avail.dayOfWeek} {avail.startTime} - {avail.endTime}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-1 ml-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(doctor)}
                      className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                      title="Editar médico"
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onDelete(doctor.id)}
                      className="text-destructive hover:text-destructive"
                      title="Excluir médico"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Formulário de Edição */}
      {editingDoctor && (
        <Card>
          <CardHeader>
            <CardTitle>Editar Médico</CardTitle>
            <CardDescription>
              Edite as informações do médico
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleEditSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="edit-crm">Registro do Médico (CRM) *</Label>
                <div className="relative">
                  <Award className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="edit-crm"
                    type="text"
                    placeholder="Digite o número do CRM"
                    value={editForm.crm}
                    onChange={(e) => setEditForm({ ...editForm, crm: formatCRM(e.target.value) })}
                    className="pl-10"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-doctor-name">Nome Completo *</Label>
                <div className="relative">
                  <UserRound className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="edit-doctor-name"
                    type="text"
                    placeholder="Digite o nome completo"
                    value={editForm.name}
                    onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                    className="pl-10"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-specialty">Especialidade *</Label>
                <div className="relative">
                  <Stethoscope className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Select
                    id="edit-specialty"
                    value={editForm.specialty}
                    onValueChange={(value) => setEditForm({ ...editForm, specialty: value })}
                    className="pl-10"
                    required
                  >
                    <SelectTrigger className="pl-10">
                      <SelectValue placeholder="Ex: Cardiologia, Clínico Geral, etc." />
                    </SelectTrigger>
                    <SelectContent>
                      {MEDICAL_SPECIALTIES.map((specialty) => (
                        <SelectItem key={specialty} value={specialty}>
                          {specialty}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-notes">Observações</Label>
                <div className="relative">
                  <FileText className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Textarea
                    id="edit-notes"
                    placeholder="Informações adicionais sobre o médico, horários de atendimento, etc."
                    value={editForm.notes}
                    onChange={(e) => setEditForm({ ...editForm, notes: e.target.value })}
                    className="pl-10 min-h-[100px]"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="edit-password">Senha *</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="edit-password"
                    type={showEditPassword ? "text" : "password"}
                    placeholder="Digite a senha"
                    value={editForm.password}
                    onChange={(e) => setEditForm({ ...editForm, password: e.target.value })}
                    className="pl-10 pr-10"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowEditPassword(!showEditPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                    tabIndex={-1}
                  >
                    {showEditPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Disponibilidade de Atendimento</Label>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={handleEditAddAvailability}
                    className="gap-2"
                  >
                    <Plus className="h-4 w-4" />
                    Adicionar Horário
                  </Button>
                </div>
                
                {editForm.availability.length === 0 ? (
                  <div className="p-6 border-2 border-dashed rounded-lg text-center text-muted-foreground">
                    <Clock className="h-8 w-8 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">Nenhum horário de atendimento cadastrado</p>
                    <p className="text-xs mt-1">Clique em "Adicionar Horário" para definir a disponibilidade</p>
                  </div>
                ) : (
                  <div className="space-y-3 p-4 border rounded-lg bg-muted/30">
                    {editForm.availability.map((avail, index) => (
                      <div key={index} className="flex flex-col sm:flex-row items-start sm:items-center gap-2 p-3 bg-white rounded-md border">
                        <div className="flex items-center gap-2 flex-1">
                          <Calendar className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                          <Select
                            value={avail.dayOfWeek}
                            onValueChange={(value) => handleEditAvailabilityChange(index, "dayOfWeek", value)}
                          >
                            <SelectTrigger className="w-[140px]">
                              <SelectValue placeholder="Dia da semana" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Segunda-feira">Segunda-feira</SelectItem>
                              <SelectItem value="Terça-feira">Terça-feira</SelectItem>
                              <SelectItem value="Quarta-feira">Quarta-feira</SelectItem>
                              <SelectItem value="Quinta-feira">Quinta-feira</SelectItem>
                              <SelectItem value="Sexta-feira">Sexta-feira</SelectItem>
                              <SelectItem value="Sábado">Sábado</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div className="flex items-center gap-2 flex-1">
                          <Clock className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                          <div className="flex items-center gap-1">
                            <Input
                              type="time"
                              value={avail.startTime}
                              onChange={(e) => handleEditAvailabilityChange(index, "startTime", e.target.value)}
                              className="w-[110px]"
                              placeholder="Início"
                            />
                            <span className="text-muted-foreground px-1">até</span>
                            <Input
                              type="time"
                              value={avail.endTime}
                              onChange={(e) => handleEditAvailabilityChange(index, "endTime", e.target.value)}
                              className="w-[110px]"
                              placeholder="Fim"
                            />
                          </div>
                        </div>
                        
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditRemoveAvailability(index)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between p-4 border rounded-lg bg-muted/30">
                  <div className="space-y-1">
                    <Label htmlFor="edit-isActive" className="cursor-pointer">
                      Status do Médico
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      {editForm.isActive 
                        ? "Médico ativo e disponível para agendamentos" 
                        : "Médico inativo e indisponível para novos agendamentos"}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-medium">
                      {editForm.isActive ? "Ativo" : "Inativo"}
                    </span>
                    <Switch
                      id="edit-isActive"
                      checked={editForm.isActive}
                      onCheckedChange={(checked) => setEditForm({ ...editForm, isActive: checked })}
                    />
                  </div>
                </div>
              </div>

              <Button type="submit" className="w-full">
                Salvar Alterações
              </Button>
            </form>
          </CardContent>
        </Card>
      )}
    </div>
  );
}